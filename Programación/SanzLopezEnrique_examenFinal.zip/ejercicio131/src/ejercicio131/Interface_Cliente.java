package ejercicio131;

public interface Interface_Cliente {
	//Devuelve el atributo nombre
	public String getNombre();
}