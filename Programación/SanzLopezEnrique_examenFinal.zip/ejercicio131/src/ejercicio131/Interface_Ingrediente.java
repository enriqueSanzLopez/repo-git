package ejercicio131;

public interface Interface_Ingrediente {
	//Devuelve el nombre y la cantidad del ingrediente
	public String detalleIngrediente();
}