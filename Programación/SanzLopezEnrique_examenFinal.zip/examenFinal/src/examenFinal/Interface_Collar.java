package examenFinal;
public interface Interface_Collar {
	
	//Calcula el precio del collar, que es la suma del precio de todas las perlas que contiene.
	public double calcular_precio();
	
	//Devuelve la descripcion del collar.
	public String toString();
}
