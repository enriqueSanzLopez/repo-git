
public class ejercicio19 {
	public static void main(String args[]) {
		System.out.printf("Inglés\t\tEspañol\n"
				+ "Hello\t\tHola\n"
				+ "Goodbye\t\tAdios\n"
				+ "Never\t\tNunca\n"
				+ "Ever\t\tSiempre\n"
				+ "Behaviour\tComportarse\n"
				+ "Understanding\tComprender\n"
				+ "Loner\t\tSolitario\n"
				+ "Account\t\tCuenta\n"
				+ "Window\t\tVentana\n"
				+ "Yellow\t\tAmarillo");
	}
}
