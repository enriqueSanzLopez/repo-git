
public class Ejercicio2 {
	public static void main(String args[]) {
		String nombre="Enrique Sanz López";
		int edad=26;
		float altura= 1.81f;
		System.out.println("Te llamas "+nombre+", tienes "+edad+" años y mides "+altura+" metros. Soy adivino!.");
	}
}
