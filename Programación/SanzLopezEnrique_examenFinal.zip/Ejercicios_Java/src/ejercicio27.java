
public class ejercicio27 {
	public static void main(String args[]) {
		//Diferentes formas de incrementar x probadas
		int x=10;
		System.out.println(x);
		//x aumenta en 1
		x++;
		System.out.println(x);
		//x aumenta en 1
		System.out.println(++x);
		System.out.println(x++);
		//x ha aumentado en 1 después de escribirse
		System.out.println(x);
		System.out.println(x++);
		System.out.println(++x);
	}
}
