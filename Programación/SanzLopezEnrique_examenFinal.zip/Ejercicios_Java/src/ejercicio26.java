
public class ejercicio26 {
	public static void main(String args[]) {
		System.out.printf("Hora\tL\tM\tX\tJ\tV\n"
				+ "14:20\tSIN\t \t \tPRO\tBDA\n"
				+ "15:15\tSIN\tPRO\t \tPRO\tBDA\n"
				+ "16:10\tSIN\tPRO\tPRO\tPRO\tBDA\n"
				+ "17:05\t \t \t \t \t \n"
				+ "17:35\tANG\tPRO\tPRO\tANG\tLMI\n"
				+ "18:30\tANG\tBDA\tFOL\tSIN\tED\n"
				+ "19:25\tFOL\tBDA\tLMI\tSIN\tED\n"
				+ "20:20\tFOL\tED\tLMI\tTut\t \n"
				+ "21:15");;
	}
}
