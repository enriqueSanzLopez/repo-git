enum dias{
	lunes, martes, miercoles, jueves, viernes, sabados, domingos
};

public class Ejercicio5 {
	public static void main(String args[]){
		System.out.println("Odio los "+dias.lunes+
				".\nLos "+dias.martes+"paso de la fase de negación a la fase de aceptación.\nCuando es "
				+dias.miercoles+" pienso que ya vamos por la mitad de la semana.\nEl previo del viernes, el "
				+dias.jueves+", es mi días favorito de la semana.\nEl "
				+dias.viernes+" suelo quedar con mis amigos para cenar.\nLos "
				+dias.sabados+" me levanto tarde y siempre desayuno tortitas.\nMe deprimen los "
				+dias.domingos+" porque pienso que mañana es "+dias.lunes+".");
	}
}
