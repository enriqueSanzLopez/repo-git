
public class ejercicio8 {
	public static void main(String args[]) {
		int a=5;
		int b=2;
		System.out.println("Bienvenido a mi calculadora.\n"
				+ "El valor de a es: "+a+"\nEl valor de b es: "+b+
				"\na + b = "+(a+b)+"\na - b = "+(a-b)+"\na x b = "
				+(a*b)+"\na / b = "+(a/b)+"\na % b = "+(a%b));
	}
}
