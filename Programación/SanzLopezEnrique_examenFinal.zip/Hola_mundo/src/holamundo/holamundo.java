package holamundo;

public class holamundo {
	public static void main(String args[]) {
		int a=10;
		int b=20;
		System.out.print(a + " y " + b + " suma ");
		System.out.println(a+b);
		System.out.println("Hola mundo!");
	}
}