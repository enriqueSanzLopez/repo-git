package actividadevaluabletrimestre3_3;
public class Criatura {
	protected String nombre;
	static String portador_anillo="";
	public Criatura(String nombre) {
		this.nombre=nombre;
	}
	public String getNombre() {
		return nombre;
	}
}