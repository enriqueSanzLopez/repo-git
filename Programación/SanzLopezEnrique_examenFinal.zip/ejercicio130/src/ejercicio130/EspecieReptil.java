package ejercicio130;
public enum EspecieReptil {
	Tortuga, Iguana, DragonDeComodo, LagartoGigante
}