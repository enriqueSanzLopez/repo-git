package ejercicio130;
public enum EspeciePajaro {
	Canario, Periquito, Agaporni
}