package ejercicio130;
public enum RazaGato {
	Comun, Siames, Persa, Angora, ScottishFold
}