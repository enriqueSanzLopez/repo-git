package ejercicio130;
public enum RazaPerro {
	PastorAleman, Husky, FoxTerrier, Dalmata, Beagle, SanBernardo
}