<footer class="bg-dark text-white">
    <h3>{{__('creditos')}}</h3>
    <section>
        <img src="{{ asset('img/IFC.png') }}" alt="{{__('logo-familia')}}" id="logo-familia">
        <img src="{{ asset('img/logoIESSerpis.jpg') }}" alt="{{__('logo-serpis')}}">
    </section>
</footer>
