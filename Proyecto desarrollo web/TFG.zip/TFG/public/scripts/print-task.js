'use strict';
let imprimir=document.getElementById('imprimir');
imprimir.addEventListener('click', function(){//Evento de impresion de tarea
    window.print();
});
