<?php $__env->startSection('titulo', __('crear-task')); ?>
<?php $__env->startSection('contenido'); ?>
    <form action="<?php echo e(route('tasks.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div>
            <label for="sprint_id">Sprint*:</label>
            <select name="sprint_id" id="sprint_id">
                <?php $__empty_1 = true; $__currentLoopData = $sprints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sprint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <option value="<?php echo e($sprint->id); ?>"><?php echo e($sprint->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    ---
                <?php endif; ?>
            </select>
        </div>
        <div>
            <label for="name"> <?php echo e(__('nombre')); ?>*:
            </label>
            <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>">
        </div>
        <div>
            <label for="description"><?php echo e(__('descripcion')); ?>:</label>
            <textarea rows="10" name="description" id="description"><?php echo e(old('description')); ?></textarea>
        </div>
        <div id="login">
            <button type="submit" class="btn btn-primary"><?php echo e(__('crear')); ?></button>
        </div>
    </form>
    <?php if($errors->any()): ?>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\Repositorio Git\Proyecto desarrollo web\TFG\resources\views/tasks/create.blade.php ENDPATH**/ ?>