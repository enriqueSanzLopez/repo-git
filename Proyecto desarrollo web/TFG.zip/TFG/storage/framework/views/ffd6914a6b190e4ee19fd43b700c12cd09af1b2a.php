<?php $__env->startSection('titulo', 'Editar - ' . $sprint->start_date); ?>
<?php $__env->startSection('contenido'); ?>
    <form action="<?php echo e(route('sprints.update', $sprint->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div>
            <label for="project_id">Proyecto*:</label>
            <select name="project_id" id="project_id">
                <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <option value="<?php echo e($project->id); ?>"><?php echo e($project->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    ---
                <?php endif; ?>
            </select>
        </div>
        <div>
            <label for="name"> Nombre*:
            </label>
            <input type="text" name="name" id="name" value="<?php echo e($sprint->name); ?>">
        </div>
        <div>
            <label for="start_date">Fecha de inicio*:</label>
            <input type="date" name="start_date" id="start_date" value="<?php echo e($sprint->start_date); ?>">
        </div>
        <div>
            <label for="limit_date">Fecha límite*:</label>
            <input type="date" name="limit_date" id="limit_date" value="<?php echo e($sprint->limit_date); ?>">
        </div>
        <div>
            <label for="backlog">Backlog:</label>
            <textarea rows="10" name="backlog" id="backlog"><?php echo e($sprint->backlog); ?></textarea>
        </div>
        <div>
            <label for="description">Descripción:</label>
            <textarea rows="10" name="description" id="description"><?php echo e($sprint->description); ?></textarea>
        </div>
        <div>
            <label for="retrospective">Retrospective:</label>
            <textarea rows="10" name="retrospective" id="retrospective"><?php echo e($sprint->retrospective); ?></textarea>
        </div>
        <div id="login">
            <a href="<?php echo e(route('sprints.show', $sprint->id)); ?>" class="btn btn-secondary">Cancelar</a>
            <button type="submit" class="btn btn-primary">Guardar cambios</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\Repositorio Git\Proyecto desarrollo web\TFG\resources\views/sprints/edit.blade.php ENDPATH**/ ?>