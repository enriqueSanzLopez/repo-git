<?php $__env->startSection('titulo', $project->name); ?>
<?php $__env->startSection('contenido'); ?>
    <section>
        <header>
            <input type="hidden" id="user" value="<?php echo e(Auth::user()->id); ?>">
            <?php if($project->owner == Auth::user()->id || Auth::user()->rol == 'admin'): ?>
                <input type="hidden" id="rol" value="true" name="rol">
            <?php else: ?>
                <input type="hidden" id="rol" value="false" name="rol">
            <?php endif; ?>
            <h1><?php echo e($project->name); ?></h1>
            <?php if($project->owner == Auth::user()->id or Auth::user()->rol == 'admin'): ?>
                
                <a href="<?php echo e(route('projects.edit', $project->id)); ?>" class="btn btn-primary"><?php echo e(__('editar')); ?></a>
                <a href="<?php echo e(route('sprints.create')); ?>" class="btn btn-primary"><?php echo e(__('crear')); ?> Sprint</a>
                <a href="<?php echo e(route('projects.borrar', $project->id)); ?>" class="btn btn-danger"><?php echo e(__('eliminar')); ?></a>
            <?php endif; ?>
        </header>
    </section>
    <section class="contenedor-horizontal">
        <section class="caracteristicas">
            <h3><?php echo e(__('descripcion')); ?></h3>
            <p><?php echo e($project->description); ?></p>
            <h3>Backlog</h3>
            <p><?php echo e($project->backlog); ?></p>
            <h3>Sprint planning</h3>
            <p><?php echo e($project->sprint_planning); ?></p>
            <h3>Listado de Sprints</h3>
            <?php if(count($project->sprints) == 0): ?>
                <h4><?php echo e(__('no-sprint-actualmente')); ?></h4>
            <?php else: ?>
                <ul>
                    <?php $__currentLoopData = $project->sprints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sprint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <div class="card" style="width: 18rem;">
                                <div class="card-body">
                                    <p class="card-text"><?php echo e($sprint->description); ?></p>
                                    <p><?php echo e($sprint->start_date); ?> - <?php echo e($sprint->limit_date); ?></p>
                                    <a href="<?php echo e(route('sprints.show', $sprint->id)); ?>" class="btn btn-primary"><?php echo e(__('entrar')); ?></a>
                                </div>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
            <h3><?php echo e(__('list-task')); ?></h3>
            <section class="listado">
                <?php $__empty_1 = true; $__currentLoopData = $project->sprints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sprint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php $__empty_2 = true; $__currentLoopData = $sprint->tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                        <div class="card" style="width: 18rem;">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($task->name); ?></h5>
                                <p><?php echo e($task->state); ?></p>
                                <p class="card-text"><?php echo e($task->description); ?></p>
                                <a href="<?php echo e(route('tasks.show', $task->id)); ?>" class="btn btn-primary"><?php echo e(__('entrar')); ?></a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                        <h4><?php echo e(__('no-task-sprint')); ?></h4>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <h4><?php echo e(__('no-task-sprint')); ?></h4>
                <?php endif; ?>
            </section>
        </section>
        <section>
            <h3><?php echo e(__('trabajadores')); ?></h3>
            <section id="listado-trabajadores">
                <?php $__empty_1 = true; $__currentLoopData = $project->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <ul class="list-group" id="lista-<?php echo e($user->id); ?>">
                        <li><?php echo e($user->name); ?></li>
                        <?php if(Auth::user()->id == $project->owner || Auth::user()->rol == 'admin'): ?>
                            <li class="borrar-user" id="borrar-user-<?php echo e($user->id . '-' . $project->id); ?>">x</li>
                        <?php endif; ?>
                        <li class="pequenyo"><?php echo e($user->email); ?></li>
                    </ul>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <h4><?php echo e(__('no-trabajadores')); ?></h4>
                <?php endif; ?>
            </section>
            <div class="busqueda">
                <input type="hidden" id="proyecto" name="proyecto" value="<?php echo e($project->id); ?>">
                <input type="search" id="busqueda" name="busqueda" placeholder="<?php echo e(__('add-trabajadores')); ?>">
            </div>
            <section class="listado-users escondido" id="usuarios">
            </section>
            <script src="<?php echo e(asset('scripts/add-user-project.js')); ?>"></script>
        </section>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\Repositorio Git\Proyecto desarrollo web\TFG\resources\views/projects/show.blade.php ENDPATH**/ ?>