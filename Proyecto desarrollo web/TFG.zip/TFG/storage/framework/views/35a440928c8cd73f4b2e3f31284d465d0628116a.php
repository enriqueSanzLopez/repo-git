<nav class="navbar navbar-expand-lg">
    <div class="container-fluid">
        <a class="navbar-brand" href="#"><img src="<?php echo e(asset('img/Scrum Admin.png')); ?>"
                alt="<?php echo e(__('logo-app')); ?>"></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="/"><?php echo e(__('inicio')); ?></a>
                </li>
                <?php if(!isset(Auth::user()->name)): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('registro')); ?>"><?php echo e(__('registro')); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('login')); ?></a>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('projects')); ?>"><?php echo e(__('proyectos')); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('sprints')); ?>">Sprints</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('tasks')); ?>"><?php echo e(__('tareas')); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('logout')); ?>"><?php echo e(__('cerrar-sesion')); ?></a>
                    </li>
                    <?php if(Auth::user()->rol == 'admin'): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('contacts')); ?>"><?php echo e(__('users')); ?></a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
                <li>
                    <select name="lang" id="lang">
                        <option value="es"
                        <?php if(isset($_COOKIE['lenguaje'])): ?>
                        <?php if($_COOKIE['lenguaje']=='es'): ?>
                        selected='selected'
                        <?php endif; ?>
                        <?php endif; ?>
                        >Español</option>
                        <option value="en"
                        <?php if(isset($_COOKIE['lenguaje'])): ?>
                        <?php if($_COOKIE['lenguaje']=='en'): ?>
                        selected='selected'
                        <?php endif; ?>
                        <?php endif; ?>
                        >English</option>
                        <option value="ca"
                        <?php if(isset($_COOKIE['lenguaje'])): ?>
                        <?php if($_COOKIE['lenguaje']=='ca'): ?>
                        selected='selected'
                        <?php endif; ?>
                        <?php endif; ?>
                        >Català</option>
                    </select>
                    <script src="<?php echo e(asset('scripts/select-lang.js')); ?>"></script>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\Users\Usuario\Desktop\Repositorio Git\Proyecto desarrollo web\TFG\resources\views/partials/nav.blade.php ENDPATH**/ ?>