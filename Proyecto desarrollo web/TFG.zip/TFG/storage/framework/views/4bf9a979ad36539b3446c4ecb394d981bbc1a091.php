<footer class="bg-dark text-white">
    <h3><?php echo e(__('creditos')); ?></h3>
    <section>
        <img src="<?php echo e(asset('img/IFC.png')); ?>" alt="<?php echo e(__('logo-familia')); ?>" id="logo-familia">
        <img src="<?php echo e(asset('img/logoIESSerpis.jpg')); ?>" alt="<?php echo e(__('logo-serpis')); ?>">
    </section>
</footer>
<?php /**PATH C:\Users\Usuario\Desktop\Repositorio Git\Proyecto desarrollo web\TFG\resources\views/partials/footer.blade.php ENDPATH**/ ?>