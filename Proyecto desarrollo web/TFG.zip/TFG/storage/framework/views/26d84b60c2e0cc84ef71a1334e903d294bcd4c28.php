<?php $__env->startSection('titulo', __('crear').' sprint'); ?>
<?php $__env->startSection('contenido'); ?>
    <form action="<?php echo e(route('sprints.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div>
            <label for="project_id"><?php echo e(__('proyecto')); ?>*:</label>
            <select name="project_id" id="project_id">
                <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <option value="<?php echo e($project->id); ?>"><?php echo e($project->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    ---
                <?php endif; ?>
            </select>
        </div>
        <div>
            <label for="name"> <?php echo e(__('nombre')); ?>*:
            </label>
            <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>">
        </div>
        <div>
            <label for="start_date"><?php echo e(__('fecha-inicio')); ?>*:</label>
            <input type="date" name="start_date" id="start_date" value="<?php echo e(old('start_date')); ?>">
        </div>
        <div>
            <label for="limit_date"><?php echo e(__('fecha-limite')); ?>*:</label>
            <input type="date" name="limit_date" id="limit_date" value="<?php echo e(old('limit_date')); ?>">
        </div>
        <div>
            <label for="backlog">Backlog:</label>
            <textarea rows="10" name="backlog" id="backlog"><?php echo e(old('backlog')); ?></textarea>
        </div>
        <div>
            <label for="description"><?php echo e(__('descripcion')); ?>:</label>
            <textarea rows="10" name="description" id="description"><?php echo e(old('description')); ?></textarea>
        </div>
        <div>
            <label for="retrospective">Retrospective:</label>
            <textarea rows="10" name="retrospective" id="retrospective"><?php echo e(old('retrospective')); ?></textarea>
        </div>
        <div id="login">
            <button type="submit" class="btn btn-primary"><?php echo e(__('crear')); ?></button>
        </div>
    </form>
    <?php if($errors->any()): ?>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\Repositorio Git\Proyecto desarrollo web\TFG\resources\views/sprints/create.blade.php ENDPATH**/ ?>