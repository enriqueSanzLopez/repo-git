<?php $__env->startSection('titulo', __('inicio')); ?>
<?php $__env->startSection('contenido'); ?>
    <?php if(!isset(Auth::user()->name)): ?>
        <div class="card" style="width: 18rem;">
            <div class="card-body">
                <h5 class="card-title">Scrum Admin</h5>
                <p class="card-text"><?php echo e(__('desarrolla')); ?><br><br>
                    <?php echo e(__('facil')); ?></p>
                <a href="<?php echo e(route('registro')); ?>" class="btn btn-primary"><?php echo e(__('registrarme')); ?></a>
            </div>
        </div>
    <?php endif; ?>
    <section class="novedades">
        
        <h1>
            <?php if(!isset(Auth::user()->name)): ?>
                <?php echo e(__('crea-desarrolla')); ?>

            <?php else: ?>
                <?php echo e(__('bienvenido')); ?> <?php echo e(Auth::user()->name); ?>

                <br>
                <a href="<?php echo e(route('calendar')); ?>" class="btn btn-primary"><?php echo e(__('imprimir-calendario')); ?></a>
            <?php endif; ?>
        </h1>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\Repositorio Git\Proyecto desarrollo web\TFG\resources\views/index.blade.php ENDPATH**/ ?>