<?php $__env->startSection('titulo', 'Eliminar - '.$task->name); ?>
<?php $__env->startSection('contenido'); ?>
    <div class="card" style="width: 18rem;">
        <div class="card-body">
            <h5 class="card-title">¿Seguro que quieres eliminar la tarea <?php echo e($task->name); ?>?</h5>
            <section>
                <a href="<?php echo e(route('tasks.show', $task->id)); ?>" class="btn btn-secondary">Cancelar</a>
                <a href="<?php echo e(route('tasks.destroy', $task->id)); ?>" class="btn btn-danger">Eliminar</a>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\Repositorio Git\Proyecto desarrollo web\TFG\resources\views/tasks/borrar.blade.php ENDPATH**/ ?>