<?php $__env->startSection('titulo', $user->name . ' - Eliminar'); ?>
<?php $__env->startSection('contenido'); ?>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">¿Seguro que quieres eliminar <?php echo e($user->name); ?>?</h5>
            <section>
                <a href="<?php echo e(route('contacts')); ?>" class="btn btn-secondary">Cancelar</a>
                <a href="<?php echo e(route('users.destroy', $user->id)); ?>" class="btn btn-danger">Eliminar</a>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\Repositorio Git\Proyecto desarrollo web\TFG\resources\views/contacts/borrar.blade.php ENDPATH**/ ?>