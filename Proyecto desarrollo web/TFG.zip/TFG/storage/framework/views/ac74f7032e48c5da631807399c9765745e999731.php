<?php $__env->startSection('titulo', 'Sprint - ' . $sprint->name); ?>
<?php $__env->startSection('contenido'); ?>
    <section>
        <header>
            <h1><?php echo e($sprint->name); ?></h1>
            <h5><?php echo e(__('del')); ?> <?php echo e($sprint->start_date); ?> <?php echo e(__('hasta')); ?> <?php echo e($sprint->limit_date); ?></h5>
            <?php if($sprint->project->owner == Auth::user()->id or Auth::user()->rol == 'admin'): ?>
                <a href="<?php echo e(route('sprints.edit', $sprint->id)); ?>" class="btn btn-primary"><?php echo e(__('editar')); ?></a>
                <a href="<?php echo e(route('tasks.create')); ?>" class="btn btn-primary"><?php echo e(__('crear-task')); ?></a>
                <a href="<?php echo e(route('sprints.borrar', $sprint->id)); ?>" class="btn btn-danger"><?php echo e(__('eliminar')); ?></a>
            <?php endif; ?>
        </header>
    </section>
    <section class="caracteristicas">
        <h3><?php echo e(__('descripcion')); ?></h3>
        <p><?php echo e($sprint->description); ?></p>
        <h3>Backlog</h3>
        <p><?php echo e($sprint->backlog); ?></p>
        <h3>Retrospective</h3>
        <p><?php echo e($sprint->retrospective); ?></p>
        <h3><?php echo e(__('list-task')); ?></h3>
        <section class="listado">
            <?php $__empty_1 = true; $__currentLoopData = $sprint->tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="card" style="width: 18rem;">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($task->name); ?></h5>
                        <p><?php echo e($task->state); ?></p>
                        <p class="card-text"><?php echo e($task->description); ?></p>
                        <a href="<?php echo e(route('tasks.show', $task->id)); ?>" class="btn btn-primary"><?php echo e(__('entrar')); ?></a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <h4><?php echo e(__('no-task-sprint')); ?></h4>
            <?php endif; ?>
        </section>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\Repositorio Git\Proyecto desarrollo web\TFG\resources\views/sprints/show.blade.php ENDPATH**/ ?>