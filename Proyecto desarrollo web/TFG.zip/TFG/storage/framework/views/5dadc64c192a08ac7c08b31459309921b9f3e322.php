<?php $__env->startSection('titulo', __('tareas') . ' - ' . $task->name); ?>
<?php $__env->startSection('contenido'); ?>
    <section>
        <header>
            <?php if($task->sprint->project->owner == Auth::user()->id or Auth::user()->rol == 'admin'): ?>
                <input type="hidden" id="rol" value="true" name="rol">
            <?php else: ?>
                <input type="hidden" id="rol" value="false" name="rol">
            <?php endif; ?>
            <input type="hidden" id="user" value="<?php echo e(Auth::user()->id); ?>" name="user">
            <h1><?php echo e($task->name); ?></h1>
            <?php if($task->sprint->project->owner == Auth::user()->id or Auth::user()->rol == 'admin'): ?>
                <a href="<?php echo e(route('tasks.edit', $task->id)); ?>" class="btn btn-primary"><?php echo e(__('editar')); ?></a>
                <a href="<?php echo e(route('tasks.borrar', $task->id)); ?>" class="btn btn-danger"><?php echo e(__('eliminar')); ?></a>
                <button type="button" class="btn btn-primary" id="imprimir"><?php echo e(__('imprimir')); ?></button>
            <?php endif; ?>
        </header>
    </section>
    <section class="contenedor-horizontal">
        <section class="caracteristicas">
            <select name="estado" id="estado" class="selectpicker">
                <option value="Sin empezar" <?php if($task->state == 'Sin empezar'): ?> selected="selected" <?php endif; ?>>
                    <?php echo e(__('sin-empezar')); ?>

                </option>
                <option value="En progreso" <?php if($task->state == 'En progreso'): ?> selected="selected" <?php endif; ?>>
                    <?php echo e(__('en-progreso')); ?>

                </option>
                <option value="A validar" <?php if($task->state == 'A validar'): ?> selected="selected" <?php endif; ?>><?php echo e(__('a-validar')); ?>

                </option>
                <option value="Finalizada" <?php if($task->state == 'Finalizada'): ?> selected="selected" <?php endif; ?>>
                    <?php echo e(__('finalizada')); ?></option>
                <option value="En revisión" <?php if($task->state == 'En revisión'): ?> selected="selected" <?php endif; ?>>
                    <?php echo e(__('en-revision')); ?>

                </option>
            </select>
            <h3><?php echo e(__('descripcion')); ?></h3>
            <p><?php echo e($task->description); ?></p>
            <h3><?php echo e(__('comments')); ?></h3>
            <div id="form-comentario">
                <input type="text" id="commentario" name="commentario" placeholder="<?php echo e(__('escribir-comment')); ?>">
                <button type="button" id="comment" class="btn btn-primary"><?php echo e(__('enviar')); ?></button>
                <hr>
            </div>
            <section class="cometarios" id="comentarios">
                <?php $__empty_1 = true; $__currentLoopData = $task->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <article>
                        <div>
                            <span>
                                <?php echo e($comment->user->name); ?> - <?php echo e($comment->user->email); ?>

                            </span>
                            <span>
                                <?php echo e($comment->date); ?>

                            </span>
                        </div>
                        <p>
                            <?php echo e($comment->comment); ?>

                        </p>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <h4><?php echo e(__('no-comments')); ?></h4>
                <?php endif; ?>
            </section>
        </section>
        <section>
            <h3><?php echo e(__('trabajadores')); ?></h3>
            <section id="listado-trabajadores">
                <?php $__empty_1 = true; $__currentLoopData = $task->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <ul class="list-group" id="lista-<?php echo e($user->id); ?>">
                        <li><?php echo e($user->name); ?></li>
                        <?php if(Auth::user()->id == $task->sprint->project->owner or Auth::user()->rol == 'admin'): ?>
                            <li class="borrar-user" id="borrar-user-<?php echo e($user->id . '-' . $task->id); ?>">x</li>
                        <?php endif; ?>
                        <li class="pequenyo"><?php echo e($user->email); ?></li>
                    </ul>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <h4><?php echo e(__('no-trabajadores')); ?></h4>
                <?php endif; ?>
            </section>
            <div class="busqueda">
                <input type="hidden" id="tarea" name="tarea" value="<?php echo e($task->id); ?>">
                <input type="search" id="busqueda" name="busqueda" placeholder="<?php echo e(__('add-trabajadores')); ?>">
            </div>
            <section class="listado-users escondido" id="usuarios">
            </section>
            <script src="<?php echo e(asset('scripts/add-comment.js')); ?>"></script>
            <script src="<?php echo e(asset('scripts/add-user-task.js')); ?>"></script>
            <script src="<?php echo e(asset('scripts/change-task-status.js')); ?>"></script>
            <script src="<?php echo e(asset('scripts/print-task.js')); ?>"></script>
        </section>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\Repositorio Git\Proyecto desarrollo web\TFG\resources\views/tasks/show.blade.php ENDPATH**/ ?>