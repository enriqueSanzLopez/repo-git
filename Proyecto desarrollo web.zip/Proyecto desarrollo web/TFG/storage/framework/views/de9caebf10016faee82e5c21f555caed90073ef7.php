<?php $__env->startSection('titulo', 'Proyectos'); ?>
<?php $__env->startSection('contenido'); ?>
    <a href="<?php echo e(route('projects.create')); ?>" class="btn btn-primary">Crear proyecto</a>
    <?php if(count($projects) == 0): ?>
        <h1>No hay proyectos</h1>
    <?php else: ?>
        <section class="listado">
            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card" style="width: 18rem;">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($project->name); ?></h5>
                        <p class="card-text"><?php echo e($project->description); ?></p>
                        <a href="<?php echo e(route('projects.show', $project->id)); ?>" class="btn btn-primary">Entrar</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\Repositorio Git\Proyecto desarrollo web\TFG\resources\views/projects/index.blade.php ENDPATH**/ ?>