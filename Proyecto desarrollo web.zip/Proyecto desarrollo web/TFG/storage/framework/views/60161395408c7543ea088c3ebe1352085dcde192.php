<?php $__env->startSection('titulo', $project->name); ?>
<?php $__env->startSection('contenido'); ?>
    <section>
        <header>
            <h1><?php echo e($project->name); ?></h1>
            <?php if($project->owner == Auth::user()->id or Auth::user()->rol=='admin'): ?>
                
                <a href="<?php echo e(route('projects.edit', $project->id)); ?>" class="btn btn-primary">Editar</a>
                <a href="<?php echo e(route('sprints.create')); ?>" class="btn btn-primary">Crear Sprint</a>
                <a href="<?php echo e(route('projects.borrar', $project->id)); ?>" class="btn btn-danger">Eliminar</a>
            <?php endif; ?>
        </header>
    </section>
    <section class="caracteristicas">
        <h3>Descripción</h3>
        <p><?php echo e($project->description); ?></p>
        <h3>Backlog</h3>
        <p><?php echo e($project->backlog); ?></p>
        <h3>Sprint planning</h3>
        <p><?php echo e($project->sprint_planning); ?></p>
        <h3>Listado de Sprints</h3>
        <?php if(count($project->sprints) == 0): ?>
            <h4>No hay Sprints actualmente</h4>
        <?php else: ?>
            <ul>
                <?php $__currentLoopData = $project->sprints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sprint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <div class="card" style="width: 18rem;">
                            <div class="card-body">
                                <p class="card-text"><?php echo e($sprint->description); ?></p>
                                <p><?php echo e($sprint->start_date); ?> - <?php echo e($sprint->limit_date); ?></p>
                                <a href="<?php echo e(route('sprints.show', $sprint->id)); ?>" class="btn btn-primary">Entrar</a>
                            </div>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>
        <h3>Listado de tareas</h3>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\Repositorio Git\Proyecto desarrollo web\TFG\resources\views/projects/show.blade.php ENDPATH**/ ?>