<?php $__env->startSection('titulo', 'Tareas'); ?>
<?php $__env->startSection('contenido'); ?>
    <a href="<?php echo e(route('tasks.create')); ?>" class="btn btn-primary">Crear tarea</a>
    <?php if(count($tasks) == 0): ?>
        <h1>No hay Tareas</h1>
    <?php else: ?>
        <section class="listado">
            <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card" style="width: 18rem;">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($task->name); ?></h5>
                        <p class="card-text"><?php echo e($task->description); ?></p>
                        <a href="<?php echo e(route('tasks.show', $task->id)); ?>" class="btn btn-primary">Entrar</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\Repositorio Git\Proyecto desarrollo web\TFG\resources\views/tasks/index.blade.php ENDPATH**/ ?>