<?php $__env->startSection('titulo', 'Tarea - ' . $task->name); ?>
<?php $__env->startSection('contenido'); ?>
    <section>
        <header>
            <h1><?php echo e($task->name); ?></h1>
            <?php if($task->sprint->project->owner == Auth::user()->id or Auth::user()->rol == 'admin'): ?>
                <a href="<?php echo e(route('tasks.edit', $task->id)); ?>" class="btn btn-primary">Editar</a>
                <a href="<?php echo e(route('tasks.borrar', $task->id)); ?>" class="btn btn-danger">Eliminar</a>
            <?php endif; ?>
        </header>
    </section>
    <section class="caracteristicas">
        <h3>Descripción</h3>
        <p><?php echo e($task->description); ?></p>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\Repositorio Git\Proyecto desarrollo web\TFG\resources\views/tasks/show.blade.php ENDPATH**/ ?>