<?php $__env->startSection('titulo', 'Contactos'); ?>
<?php $__env->startSection('contenido'); ?>
    <section class="listado-users" id="lugar">
        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <ul class="list-group list-group-horizontal">
                <li class="list-group-item"><?php echo e($user->name); ?></li>
                <li class="list-group-item"><?php echo e($user->email); ?></li>
                <li class="list-group-item">
                    <select name="rol" id="<?php echo e('rol-' . $user->id); ?>" class="form-select form-select-lg"
                        aria-label=".form-select-lg example">
                        <?php if($user->rol == 'admin'): ?>
                            <option value="0">Usuario</option>
                            <option value="1"selected>Administrador</option>
                        <?php else: ?>
                            <option value="0" selected>Usuario</option>
                            <option value="1">Administrador</option>
                        <?php endif; ?>
                    </select>
                </li>
            </ul>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h1>No hay usuarios registrados</h1>
        <?php endif; ?>
    </section>
    <script src="<?php echo e(asset('scripts/change-rol.js')); ?>">
        const url_parcial="<?php echo e(route('inicio')); ?>";
        createEvent(url_parcial);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\Repositorio Git\Proyecto desarrollo web\TFG\resources\views/contacts/index.blade.php ENDPATH**/ ?>