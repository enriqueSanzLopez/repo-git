<?php $__env->startSection('titulo', 'Crear sprint'); ?>
<?php $__env->startSection('contenido'); ?>
    <form action="<?php echo e(route('sprints.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div>
            <label for="project_id">Proyecto*:</label>
            <select name="project_id" id="project_id">
                <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <option value="<?php echo e($project->id); ?>"><?php echo e($project->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    ---
                <?php endif; ?>
            </select>
        </div>
        <div>
            <label for="name"> Nombre*:
            </label>
            <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>">
        </div>
        <div>
            <label for="start_date">Fecha de inicio*:</label>
            <input type="date" name="start_date" id="start_date" value="<?php echo e(old('start_date')); ?>">
        </div>
        <div>
            <label for="limit_date">Fecha límite*:</label>
            <input type="date" name="limit_date" id="limit_date" value="<?php echo e(old('limit_date')); ?>">
        </div>
        <div>
            <label for="backlog">Backlog:</label>
            <textarea rows="10" name="backlog" id="backlog"><?php echo e(old('backlog')); ?></textarea>
        </div>
        <div>
            <label for="description">Descripción:</label>
            <textarea rows="10" name="description" id="description"><?php echo e(old('description')); ?></textarea>
        </div>
        <div>
            <label for="retrospective">Retrospective:</label>
            <textarea rows="10" name="retrospective" id="retrospective"><?php echo e(old('retrospective')); ?></textarea>
        </div>
        <div id="login">
            <button type="submit" class="btn btn-primary">Crear</button>
        </div>
    </form>
    <?php if($errors->any()): ?>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\Repositorio Git\Proyecto desarrollo web\TFG\resources\views/sprints/create.blade.php ENDPATH**/ ?>