<footer class="bg-dark text-white">
    <h3>Desarrollado por Enrique Sanz López - 2023</h3>
    <section>
        <img src="<?php echo e(asset('img/IFC.png')); ?>" alt="Logotipo Familia Informática y comunicaciones" id="logo-familia">
        <img src="<?php echo e(asset('img/logoIESSerpis.jpg')); ?>" alt="Logotipo IES Serpis">
    </section>
</footer>
<?php /**PATH C:\Users\Usuario\Desktop\Repositorio Git\Proyecto desarrollo web\TFG\resources\views/partials/footer.blade.php ENDPATH**/ ?>