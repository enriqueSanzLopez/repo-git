@extends('layout')
@section('titulo', 'Tareas')
@section('contenido')
    <h1>No hay tareas</h1>
@endsection
