@extends('layout')
@section('titulo', 'Contactos')
@section('contenido')
    <h1>No hay contactos</h1>
@endsection
