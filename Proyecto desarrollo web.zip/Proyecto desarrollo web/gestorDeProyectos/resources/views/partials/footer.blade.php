<footer class="bg-dark text-white">
    <h3>Desarrollado por Enrique Sanz López - 2023</h3>
    <section>
        <img src="img/IFC.png" alt="Logotipo Familia Informática y comunicaciones" id="logo-familia">
        <img src="img/logoIESSerpis.jpg" alt="Logotipo IES Serpis">
    </section>
</footer>
