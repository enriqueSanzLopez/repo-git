<?php $__env->startSection('titulo', 'Inicio'); ?>
<?php $__env->startSection('contenido'); ?>
    <?php if(!isset(Auth::user()->name)): ?>
        <div class="card" style="width: 18rem;">
            <div class="card-body">
                <h5 class="card-title">Scrum Admin</h5>
                <p class="card-text">Desarrolla tus proyectos con nosotros<br><br>
                    Fácil, rápido, simple</p>
                <a href="<?php echo e(route('registro')); ?>" class="btn btn-primary">Registrarme</a>
            </div>
        </div>
    <?php endif; ?>
    <section class="novedades">
        
        <h1>Hola mundo</h1>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\Repositorio Git\Proyecto desarrollo web\gestorDeProyectos\resources\views/index.blade.php ENDPATH**/ ?>