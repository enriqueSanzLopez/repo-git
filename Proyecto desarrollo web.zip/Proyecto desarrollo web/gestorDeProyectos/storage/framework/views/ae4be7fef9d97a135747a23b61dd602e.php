<?php $__env->startSection('titulo', $project->name.' - Editar'); ?>
<?php $__env->startSection('contenido'); ?>
    <form action="<?php echo e(route('projects.update', $project->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div>
            <label for="name"> Nombre*:
            </label>
            <input type="text" name="name" id="name" value="<?php echo e($project->name); ?>">
        </div>
        <div>
            <label for="sprint_planning">Sprint planning:</label>
            <textarea rows="10" name="sprint_planning" id="sprint_planning"><?php echo e($project->sprint_planning); ?></textarea>
        </div>
        <div>
            <label for="backlog">Backlog:</label>
            <textarea rows="10" name="backlog" id="backlog"><?php echo e($project->backlog); ?></textarea>
        </div>
        <div>
            <label for="description">Descripción:</label>
            <textarea rows="10" name="description" id="description"><?php echo e($project->description); ?></textarea>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="checkbox" id="visibility" name="visibility"
                <?php if($project->visibility == 1): ?> checked <?php endif; ?>>
            <label class="form-check-label" for="visibility">
                Visible
            </label>
        </div>
        <div id="login">
            <a href="<?php echo e(route('projects.show', $project->id)); ?>" class="btn btn-secondary">Cancelar</a>
            <button type="submit" class="btn btn-primary">Guardar cambios</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\Repositorio Git\Proyecto desarrollo web\gestorDeProyectos\resources\views/projects/edit.blade.php ENDPATH**/ ?>