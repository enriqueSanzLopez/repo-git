<?php $__env->startSection('titulo', $project->name); ?>
<?php $__env->startSection('contenido'); ?>
    <section>
        <header>
            <h1><?php echo e($project->name); ?></h1>
            <?php if($project->owner == Auth::user()->id): ?>
                
                <a href="<?php echo e(route('projects.edit', $project->id)); ?>" class="btn btn-primary">Editar</a>
                <a href="<?php echo e(route('sprints.create')); ?>" class="btn btn-primary">Crear Sprint</a>
                <a href="<?php echo e(route('projects.borrar', $project->id)); ?>" class="btn btn-danger">Eliminar</a>
            <?php endif; ?>
        </header>
    </section>
    <section class="caracteristicas">
        <h3>Descripción</h3>
        <p><?php echo e($project->description); ?></p>
        <h3>Backlog</h3>
        <p><?php echo e($project->backlog); ?></p>
        <h3>Sprint planning</h3>
        <p><?php echo e($project->sprint_planning); ?></p>
        <h3>Listado de Sprints</h3>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\Repositorio Git\Proyecto desarrollo web\gestorDeProyectos\resources\views/projects/show.blade.php ENDPATH**/ ?>