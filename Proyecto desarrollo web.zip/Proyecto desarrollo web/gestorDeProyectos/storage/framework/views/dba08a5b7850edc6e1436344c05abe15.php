<?php $__env->startSection('titulo', 'Crear proyecto'); ?>
<?php $__env->startSection('contenido'); ?>
    <form action="<?php echo e(route('projects.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div>
            <label for="name"> Nombre*:
            </label>
            <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>">
        </div>
        <div>
            <label for="sprint_planning">Sprint planning:</label>
            <textarea rows="10" name="sprint_planning" id="sprint_planning"><?php echo e(old('sprint_planning')); ?></textarea>
        </div>
        <div>
            <label for="backlog">Backlog:</label>
            <textarea rows="10" name="backlog" id="backlog"><?php echo e(old('backlog')); ?></textarea>
        </div>
        <div>
            <label for="description">Descripción:</label>
            <textarea rows="10" name="description" id="description"><?php echo e(old('description')); ?></textarea>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="checkbox" id="visibility" name="visibility" checked>
            <label class="form-check-label" for="visibility">
            Visible
            </label>
        </div>
        <div id="login">
            <button type="submit" class="btn btn-primary">Crear</button>
        </div>
    </form>
    <?php if($errors->any()): ?>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\Repositorio Git\Proyecto desarrollo web\gestorDeProyectos\resources\views/projects/create.blade.php ENDPATH**/ ?>