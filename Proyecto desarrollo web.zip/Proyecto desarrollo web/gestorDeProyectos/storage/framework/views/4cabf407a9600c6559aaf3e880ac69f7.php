<?php $__env->startSection('titulo', 'Sprint - '.$sprint->start_date); ?>
<?php $__env->startSection('contenido'); ?>
    <section>
        <header>
            <h1>Del <?php echo e($sprint->start_date); ?> hasta el <?php echo e($sprint->limit_date); ?></h1>
            <?php
            var_dump($sprint->project()->name);
            ?>
        </header>
    </section>
    <section class="caracteristicas">
        <h3>Descripción</h3>
        <p><?php echo e($sprint->description); ?></p>
        <h3>Backlog</h3>
        <p><?php echo e($sprint->backlog); ?></p>
        <h3>Retrospectiva</h3>
        <p><?php echo e($sprint->retrospective); ?></p>
        <h3>Listado de Tareas</h3>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\Repositorio Git\Proyecto desarrollo web\gestorDeProyectos\resources\views/sprints/show.blade.php ENDPATH**/ ?>