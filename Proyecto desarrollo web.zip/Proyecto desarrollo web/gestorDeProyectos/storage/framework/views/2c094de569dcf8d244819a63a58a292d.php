<?php $__env->startSection('titulo', 'Contactos'); ?>
<?php $__env->startSection('contenido'); ?>
    <h1>No hay contactos</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\Repositorio Git\Proyecto desarrollo web\gestorDeProyectos\resources\views/contacts/index.blade.php ENDPATH**/ ?>