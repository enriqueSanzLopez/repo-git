<?php $__env->startSection('titulo', 'Iniciar sesión'); ?>
<?php $__env->startSection('contenido'); ?>
    <form action="<?php echo e(route('loginddbb')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div>
            <label for="name"> Nombre:
            </label>
            <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>">
        </div>
        <div>
            <label for="password"> Contraseña:
            </label>
            <input type="password" name="password" id="password" value="<?php echo e(old('password')); ?>">
        </div>
        <div id="login">
            <button type="submit" class="btn btn-primary">Iniciar sesión</button>
        </div>
    </form>
    <?php if($errors->any()): ?>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\Repositorio Git\Proyecto desarrollo web\gestorDeProyectos\resources\views/login/login.blade.php ENDPATH**/ ?>