<?php $__env->startSection('titulo', 'Sprints'); ?>
<?php $__env->startSection('contenido'); ?>
    <a href="<?php echo e(route('sprints.create')); ?>" class="btn btn-primary">Crear sprint</a>
    <?php if(count($sprints) == 0): ?>
        <h1>No hay sprints</h1>
    <?php else: ?>
        <section class="listado">
            <?php $__currentLoopData = $sprints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sprint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card" style="width: 18rem;">
                    <div class="card-body">
                        <p class="card-text"><?php echo e($sprint->description); ?></p>
                        <p><?php echo e($sprint->start_date); ?> - <?php echo e($sprint->limit_date); ?></p>
                        <a href="<?php echo e(route('sprints.show', $sprint->id)); ?>" class="btn btn-primary">Entrar</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\Repositorio Git\Proyecto desarrollo web\gestorDeProyectos\resources\views/sprints/index.blade.php ENDPATH**/ ?>