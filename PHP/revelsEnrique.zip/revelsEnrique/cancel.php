<?php
session_start();
if (!isset($_SESSION['user'])) { //Si no se ha iniciado sesión o se ha entrado incorrectamente, se redirige a index
    //header('Location: index.php');
    exit();
}
if (isset($_POST['aceptar']) and $_POST['aceptar']==1) {//Se ha enviado el formulario de eliminación correctamente
    try {
        $conexion = new PDO('mysql:host=localhost;dbname=revels', 'revel', 'lever'); //Conectar con la base de datos
        $conexion->beginTransaction();//Iniciar el borrado
        $borrar=$conexion->query('DELETE FROM comments WHERE userid='.$_SESSION['user'].';');//Borrar comentarios, funciona
        $revelsid=$conexion->query('SELECT id FROM revels WHERE userid='.$_SESSION['user'].';');//Conseguir las id's de las revels del usuario
        foreach ($revelsid->fetchAll(PDO::FETCH_ASSOC) as $fila) {//Se que no es la forma más adecuada, pero no me defuncionaba si usaba IN como si fuera un array
            $borrar=$conexion->query('DELETE FROM comments WHERE revelid='.$fila['id'].';');//Borrar todos los comentarios de la revel
            $borrar=$conexion->query('DELETE FROM revels WHERE id='.$fila['id'].';');//Borrar todos la revel
        }//Originalmente la query era esta, pero a ratos me acepta $ids y a ratos no para las queries
        /*$ids=implode(',', $revelsid->fetchAll(PDO::FETCH_COLUMN, 0));
        $ids='('.$ids.')';
        $borrar=$conexion->query('DELETE FROM comments WHERE revelid IN '.$ids.';');//Borrar los comentarios de otros usuarios sobre mis revels
        $borrar=$conexion->query('DELETE FROM revels WHERE id IN '.$ids.';');//Borrar todas las revel del usuario*/
        $borrar=$conexion->query('DELETE FROM follows WHERE userid='.$_SESSION['user'].' OR userfollowed='.$_SESSION['user'].';');//Borrar el listado de seguidos y seguidores del usuario
        $borrar=$conexion->query('DELETE FROM users WHERE id='.$_SESSION['user'].';');//Borrar al propio usuario
        $conexion->commit();
        unset($ids);//Cerrar la conexión con la base de datos
        unset($revelsid);
        unset($borrar);
        unset($conexion);
        session_destroy();//Cerrar la sesión
        header('Location: index.php');//Retornar a index sin sesión iniciada tras destruir los datos del usuario
        exit();
    } catch (PDOException $e) {//Si falla la base de datos
        $conexion->rollback();
        echo '<p class="error">Parece que hay un problema con la base de datos, inténtelo más tarde</p>';
    }
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <!--Nombre de la pestaña-->
    <title>Borrar</title>
    <!--Metadatos-->
    <meta charset="utf-8" name="Author: Enrique Sanz López">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--Enlace al CSS-->
    <link rel="stylesheet" href="css/estiloBack.css">
    <link href="img/R.ico" rel="icon">
</head>

<body>
    <?php
    require_once('inc/cabecera.inc.php');
    require_once('inc/navegacionOn.inc.php');
    echo '<section>';
    echo '<article>
        <h2>¿Estás seguro de querer borrar a tu usuario de nuestra aplicación?</h2>
        <form action="#" method="post">
            <input type="checkbox" id="aceptar" name="aceptar" value="1">
            <label for="aceptar">Acepto borrar mi cuenta</label><br>
            <button type="submit">Borrar</button>
        </form>
    </article>';
    echo '</section>';
    ?>
</body>

</html>