<?php
session_start(); //Iniciar sesión
$errores = ['nick' => '', 'contrasenya' => '', 'noExiste' => '', 'vacio' => '', 'incorrecto' => '']; //Declarar los posibles errores
if (!isset($_POST['nick']) and !isset($_POST['contrasenya'])) { //El formulario está vacío
    $errores['vacio'] = '<p class="error">Está vacío</p>';
}
if (isset($_POST['nick'])) { //Existe el nick de usuario
    if (!preg_match('/[0-9a-z]{1,}/i', $_POST['nick'])) { //El nick está vacío
        $errores['nick'] = '<p class="error">El nobmre de usuario no puede estar vacío</p>';
    }
}
if (isset($_POST['contrasenya'])) {
    if (!preg_match('/[0-9a-z]{1,}/i', $_POST['contrasenya'])) { //La contraseña está vacía
        $errores['contrasenya'] = '<p class="error">La contraseña no puede estar vacía</p>';
    }
}
if ($errores['nick'] == '' and $errores['contrasenya'] == '' and $errores['vacio'] == '') { //Comprobar si se ha iniciado sesión correctametne
    try {
        $conexion = new PDO('mysql:host=localhost;dbname=revels', 'revel', 'lever'); //Conectar con la base de datos
        $busqueda = $conexion->prepare('SELECT * FROM users WHERE usuario=:nick;'); //Preparar la consulta para evitar el SQL inject
        $busqueda->bindParam(':nick', $_POST['nick']);
        $busqueda->execute();
        if ($busqueda->rowCount()==0) {//El usuario no existe
            $errores['noExiste']='<p class="error">El usuario indicado no existe</p>';
        } else {//El usuario existe, mirar si la contraseña es correcta
            $datos=$busqueda->fetch(PDO::FETCH_ASSOC);
            $contrasenya=$datos['contrasenya'];//Conseguir la contraseña y la id de la base de datos
            $id=$datos['id'];
            if (password_verify($_POST['contrasenya'], $contrasenya)) {//La contraseña es correcta
                $_SESSION['user']=$id;//Abrir sesión
                unset($fila);//Cerrar la conexión con la base de datos
                unset($busqueda);
                unset($conexion);
                header('Location: index.php');//Enviar a index con la sesión iniciada
                exit();
            }
        }
        unset($fila); //Cerrar la conexión con la base de datos
        unset($busqueda);
        unset($conexion);
    } catch (PDOException $e) { //Ha habido un fallo con la base de datos
        echo '<p class="error">Fallo en la base de datos, por favor, inténtelo más tarde</p>';
    }
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <!--Nombre de la pestaña-->
    <title>Login</title>
    <!--Metadatos-->
    <meta charset="utf-8" name="Author: Enrique Sanz López">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--Enlace al CSS-->
    <link rel="stylesheet" href="css/estiloBase.css">
    <link href="img/R.ico" rel="icon">
</head>

<body>
    <?php
    require_once('inc/cabecera.inc.php');
    require_once('inc/navegacionOff.inc.php');
    ?>
    <section>
        <article>
            <h2>Inicia sesión</h2>
            <form action="#" method="post">
                <label for="nick">Nombre: </label>
                <input type="text" name="nick" id="nick"><br>
                <label for="contrasenya">Contraseña: </label>
                <input type="text" name="contrasenya" id="contrasenya"><br>
                <button type="submit">Iniciar sesión</button>
            </form>
        </article>
    </section>
</body>

</html>