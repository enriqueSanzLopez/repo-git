<?php
session_start();
if (!isset($_SESSION['user']) or !isset($_POST['comentario'])) {//Si no se ha iniciado sesión o se ha entrado incorrectamente, se redirige a index
    header('Location: index.php');
    exit();
}
if (preg_match('/[a-z0-9]{1,}/i', $_POST['comentario'])) {//El comentario no está vacío
    try {
        $conexion=new PDO('mysql:host=localhost;dbname=revels', 'revel', 'lever');//Conectar con la base de datos
        $subir=$conexion->prepare('INSERT INTO comments (revelid, userid, texto)
            VALUES (:revel, :usuario, :comentario);');//Introducir el comentario en la base de datos
        $subir->bindParam(':revel', $_POST['revel']);
        $subir->bindParam(':usuario', $_SESSION['user']);
        $subir->bindParam(':comentario', $_POST['comentario']);
        $subir->execute();
    } catch (PDOException) {
        header('Location: revel.php?id='.$_POST['revel'].'&error=1');//Si no funciona, retorna al revel e indica el fallo
        echo 'Error con la base de datos';
        exit();
    }
}
header('Location: revel.php?id='.$_POST['revel']);//Cuando termine retorna al revel
exit();
?>