<?php
session_start();//Iniciar sesión
if (!isset($_SESSION['user'])) {//Si no se ha iniciado sesión o se ha entrado incorrectamente, se redirige a index
    header('Location: index.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <!--Nombre de la pestaña-->
    <title>List</title>
    <!--Metadatos-->
    <meta charset="utf-8" name="Author: Enrique Sanz López">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--Enlace al CSS-->
    <link rel="stylesheet" href="css/estiloBack.css">
    <link href="img/R.ico" rel="icon">
</head>

<body>
    <?php
    require_once('inc/cabecera.inc.php');
    require_once('inc/navegacionBack.inc.php');
    echo '<section>';
    require_once('inc/aside.inc.php');
    echo '<article>';
    try {
        $conexion=new PDO('mysql:host=localhost;dbname=revels', 'revel', 'lever');//Conectar con la base de datos
        $lista=$conexion->query('SELECT * FROM revels WHERE userid='.$_SESSION['user'].';');//Conseguir las id de los usuarios
        echo '<ul>';
        foreach ($lista->fetchAll(PDO::FETCH_ASSOC) as $fila) {
            echo '<li>'.$fila['texto'].'<form action="delete.php" method="post">
            <input type="hidden" name="borrar" id="borrar" value="'.$fila['id'].'">
            <button type="submit">Borrar</button>
            </form>
            </li>';//Mostrar cada revel con su formulario de borrado
        }
        echo '</ul>';
        unset($fila);//Cerrar la conexión con la base de datos
        unset($lista);
        unset($conexion);
    } catch (PDOException $e) {//Si no se puede conectar a la base de datos
        echo '<p class="error">No se ha podido visualizar el listado de revels, por favor inténtelo más tarde</p>';
    }
    echo '</article>';
    echo '</section>';
    ?>
</body>

</html>