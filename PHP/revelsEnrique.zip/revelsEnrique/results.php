<?php
session_start();
if (!isset($_SESSION['user']) or !isset($_GET['busqueda'])) {//Si no se ha iniciado sesión o se ha entrado incorrectamente, se redirige a index
    header('Location: index.php');
    exit();
}
if (isset($_POST['seguir'])) {//Se quiere seguir a un usuario
    try {
        $conexion = new PDO('mysql:host=localhost;dbname=revels', 'revel', 'lever');//Conectarse a la base de datos
        $seguido=$conexion->prepare('SELECT * FROM follows WHERE userid=:tu AND userfollowed=:seguir;');//Comprobar si ya seguía al usuario indicado
        $seguido->bindParam(':tu', $_SESSION['user']);
        $seguido->bindParam(':seguir', $_POST['seguir']);
        $seguido->execute();
        $existe=$conexion->prepare('SELECT * FROM users WHERE id=:codigo');//Comprobar que existe el usuario al que intentamos seguir
        $existe->bindParam(':codigo', $_POST['seguir']);
        $existe->execute();
        if ($seguido->rowCount()==0 and $existe->rowCount()!=0) {//El usuario no era seguido y existe, así que se inicia la gestión para que sea seguido
            $seguido=$conexion->prepare('INSERT INTO follows (userid, userfollowed) VALUES (:usuario, :seguido);');//Indicar a la base de datos que el usuario sigue a esta persona
            $seguido->bindParam(':usuario', $_SESSION['user']);
            $seguido->bindParam(':seguido', $_POST['seguir']);
            $seguido->execute();
        }
        unset($existe);
        unset($seguido);//Cerrar la conexión con la base de datos
        unset($conexion);
    } catch (PDOException $e) {//Si falla la base datos
        echo '<p class="error">No se ha podido seguir al usuario, inténtelo más tarde</p>';
    }
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <!--Nombre de la pestaña-->
    <title>Resultados</title>
    <!--Metadatos-->
    <meta charset="utf-8" name="Author: Enrique Sanz López">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--Enlace al CSS-->
    <link rel="stylesheet" href="css/estiloBase.css">
    <link href="img/R.ico" rel="icon">
</head>

<body>
    <?php
    require_once('inc/cabecera.inc.php');//Incluir cabecera y navegación
    require_once('inc/navegacionOn.inc.php');
    echo '<section>';
    require_once('inc/aside.inc.php');
    echo '<article>';
    try {
        $conexion = new PDO('mysql:host=localhost;dbname=revels', 'revel', 'lever');//Conectarse a la base de datos
        $busqueda=$conexion->query('SELECT userfollowed FROM follows WHERE userid='.$_SESSION['user'].';');//Conseguir los usuarios a los que ya se sigue
        $seguidos=$busqueda->fetchAll(PDO::FETCH_COLUMN, 0);//Guardar las id's de usuarios seguidos
        $busqueda=$conexion->prepare('SELECT * FROM users WHERE usuario LIKE :user AND id!='.$_SESSION['user'].';');//Conseguir los resultados de la búsqueda con la que se ha entrado a la página
        $_GET['busqueda']='%'.$_GET['busqueda'].'%';
        $busqueda->bindParam(':user', $_GET['busqueda']);
        $busqueda->execute();
        echo '<ul>';
        foreach ($busqueda->fetchAll(PDO::FETCH_ASSOC) as $fila) {//Mostrar los resultados de la búsqueda, con un formulario post para seguir a los usuarios mostrados
            if (in_array($fila['id'], $seguidos)) {//Ya se seguía al usuario
                echo '<li>'.$fila['usuario'].'/'.$fila['email'].'    
                    <form action="#" method="post">
                    <input type="hidden" name="fborrar" id="fborrar" value="'.$fila['id'].'">
                    <button type="submit">Dejar de seguir</button>
                    </form>
                </li>';
            } else {//No se seguía ya a este usuario
                echo '<li>'.$fila['usuario'].'/'.$fila['email'].'    
                    <form action="#" method="post">
                    <input type="hidden" name="seguir" id="seguir" value="'.$fila['id'].'">
                    <button type="submit">Seguir</button>
                    </form>
                </li>';
            }
        }
        echo '</ul>';
        unset($fila);//Cerrar la conexión con la base de datos
        unset($busqueda);
        unset($conexion);
    } catch (PDOException $e) {//Si falla la base de datos
        echo '<p class="error">No se ha podido realizar la búsqueda, por favor inténtelo más tarde</p>';
    }
    echo '</article>
    </section>';
    ?>
</body>

</html>