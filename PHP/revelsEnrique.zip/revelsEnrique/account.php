<?php
session_start();
if (!isset($_SESSION['user'])) { //Si no se ha iniciado sesión o se ha entrado incorrectamente, se redirige a index
    header('Location: index.php');
    exit();
}
$errores = ['nick' => '', 'mail' => '', 'antigua' => '', 'nueva' => '', 'repite' => ''];
if (isset($_POST['nick']) and isset($_POST['mail']) and isset($_POST['antigua']) and isset($_POST['nueva']) and isset($_POST['repite'])) { //Se ha enviado el formulario
    if (!preg_match('/[0-9a-z]{1,}/i', $_POST['nick'])) { //El nick está vacío
        $errores['nick'] = '<p class="error">El nobmre de usuario no puede estar vacío</p>';
    }
    if (!preg_match('/^[a-z_0-9.]+@[a-z]+\.[a-z]{2,3}$/', $_POST['mail'])) { //El mail no tiene un formato adecuado
        $errores['mail'] = '<p class="error">El email tiene un formato incorrecto</p>';
    }
    if (!preg_match('/[0-9a-z]{1,}/i', $_POST['nueva'])) { //La contraseña está vacía
        $errores['nueva'] = '<p class="error">La nueva contraseña no puede estar vacía</p>';
    } else if ($_POST['nueva'] != $_POST['repite']) { //La contraseña y la contraseña repetida no son iguales
        $errores['repite'] = '<p class="error">Has fallado repitiendo la contraseña</p>';
    }
    try {
        $conexion = new PDO('mysql:host=localhost;dbname=revels', 'revel', 'lever'); //Conectar con la base de datos
        $contrasenya=$conexion->query('SELECT contrasenya FROM users WHERE id='.$_SESSION['user'].';');//Conseguir la contraseña cifrada del usuario
        foreach ($contrasenya->fetchAll(PDO::FETCH_ASSOC) as $fila) {//Comprobar si la contraseña antigua está bien puesta
            if (!password_verify($_POST['antigua'], $fila['contrasenya'])) {//La contraseña no se ha introducido bien
                $errores['antigua']='<p class="errores">La contraseña introducida es incorrecta</p>';
            }
        }
        if ($errores['nick']=='' and $errores['mail']=='' and $errores['antigua']=='' and $errores['nueva']=='' and $errores['repite']=='') {//Se ha introducido la contraseña correctamente
            $encriptada=password_hash($_POST['nueva'], PASSWORD_DEFAULT);//Encriptar la contraseña
            $actualiza=$conexion->prepare('UPDATE users
                SET usuario=:nick, contrasenya=:encriptada, email=:mail
                WHERE id='.$_SESSION['user'].';');//Actualizar la cuenta
            $actualiza->bindParam(':nick', $_POST['nick']);
            $actualiza->bindParam(':encriptada', $encriptada);
            $actualiza->bindParam(':mail', $_POST['mail']);
            $actualiza->execute();
        }
        unset($actualiza);
        unset($contrasenya);//Cerrar la conexión con la base datos
        unset($conexion);
    } catch (PDOException $e) {//Si falla la base de datos
        $errores['antigua']='<p class="error">Error ddbb</p>';
        echo '<p class="error">En estos momentos estamos teniendo problemas para actualizar tus datos, sentimos las molestias, vuelva a intentarlo más tarde</p>';
    }
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <!--Nombre de la pestaña-->
    <title>Cuenta</title>
    <!--Metadatos-->
    <meta charset="utf-8" name="Author: Enrique Sanz López">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--Enlace al CSS-->
    <link rel="stylesheet" href="css/estiloBack.css">
    <link href="img/R.ico" rel="icon">
</head>

<body>
    <?php
    require_once('inc/cabecera.inc.php');
    require_once('inc/navegacionBack.inc.php');
    echo '<section>';
    require_once('inc/aside.inc.php');
    try {
        $conexion = new PDO('mysql:host=localhost;dbname=revels', 'revel', 'lever'); //Conectar con la base de datos
        $usuario = $conexion->query('SELECT * FROM users WHERE id=' . $_SESSION['user'] . ';'); //Extraer la información del usuario
        foreach ($usuario->fetchAll(PDO::FETCH_ASSOC) as $fila) {
            echo '<article>
                <h2>Cambiar datos</h2>
                <form action="#" method="post">
                    <label for="nick">Nombre: </label>
                    <input type="text" name="nick" id="nick" value="' . $fila['usuario'] . '"><br>
                    <label for="mail">Email: </label>
                    <input type="text" name="mail" id="mail" value="' . $fila['email'] . '"><br>
                    <label for="antigua">Repite tu contraseña antigua: </label>
                    <input type="text" name="antigua" id="antigua"><br>
                    <label for="nueva">Nueva contraseña: </label>
                    <input type="text" name="nueva" id="nueva"><br>
                    <label for="repite">Repite la nueva contraseña: </label>
                    <input type="text" name="repite" id="repite"><br>
                    <button type="submit">Actualizar</button>
                    <a href="account.php" alt="Enlace roto a account"><button type="button">Cancela</button></a>
                </form>
                <a href="list.php" alt="No se han podido listar las revels del usuario"><button type="button">Listar tus revels</button></a>
            </article>';
            break;
        }
        unset($fila);//Cerrar la conexión con la base de datos
        unset($usuario);
        unset($conexion);
    } catch (PDOException $e) { //Si hay un fallo con la base de datos
        echo '<p class="error">No se ha podido cargar el formulario de modificación de datos, por favor inténtelo abrir más tarde</p>';
    }
    echo '</section>';
    ?>
</body>

</html>