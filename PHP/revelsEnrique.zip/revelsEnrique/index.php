<?php
session_start(); //Iniciar sesión
$errores = ['nick' => '', 'mail' => '', 'contrasenya' => '', 'rcontrasenya' => '', 'existe' => '', 'vacio' => '']; //En un inicio se asume que no hay errores, y en caso de haberlos, se indica después
if (!isset($_SESSION['user'])) { //No se ha iniciado sesión
    if (!isset($_POST['nick']) and !isset($_POST['mail']) and !isset($_POST['contrasenya'])) {
        $errores['vacio'] = '<p class="error">Está vacío</p>';
    }
    if (isset($_POST['nick'])) { //Existe el nick de usuario
        if (!preg_match('/[0-9a-z]{1,}/i', $_POST['nick'])) { //El nick está vacío
            $errores['nick'] = '<p class="error">El nobmre de usuario no puede estar vacío</p>';
        }
    }
    if (isset($_POST['mail'])) {
        if (!preg_match('/^[a-z_.]+@[a-z]+\.[a-z]{2,3}$/', $_POST['mail'])) { //El mail no tiene un formato adecuado
            $errores['mail'] = '<p class="error">El email tiene un formato incorrecto</p>';
        }
    }
    if (isset($_POST['contrasenya'])) {
        if (!preg_match('/[0-9a-z]{1,}/i', $_POST['contrasenya'])) { //La contraseña está vacía
            $errores['contrasenya'] = '<p class="error">La contraseña no puede estar vacía</p>';
        } else if ($_POST['contrasenya'] != $_POST['rcontrasenya']) { //La contraseña y la contraseña repetida no son iguales
            $errores['rcontrasenya'] = '<p class="error">Has fallado repitiendo la contraseña</p>';
        }
    }
    if ($errores['nick'] == '' and $errores['mail'] == '' and $errores['contrasenya'] == '' and $errores['rcontrasenya'] == '' and $errores['vacio'] == '') { //No hay errores en el formulario por lo que se debe comprobar en la base de datos si ya existe el usuario que se quiere crear
        try {
            $conexion = new PDO('mysql:host=localhost;dbname=revels', 'revel', 'lever'); //Conectar con la base de datos
            $busqueda = $conexion->prepare('SELECT usuario FROM users WHERE usuario=:nick;'); //Preparar la consulta para evitar el SQL inject
            $busqueda->bindParam(':nick', $_POST['nick']);
            $busqueda->execute();
            if (count($busqueda->fetchAll(PDO::FETCH_ASSOC)) != 0) { //El nick seleccionado ya existe
                $errores['existe'] = '<p class="error">El nombre indicado ya existe, por favor selsccione un nuevo nombre</p>';
            }
            if ($errores['existe'] == '') { //El usuario no existía con lo que se procede a crearlo y a crear sesión
                try {
                    $contrasenya = password_hash($_POST['contrasenya'], PASSWORD_DEFAULT); //Encriptar la contraseña antes de guardarla en la base de datos
                    $busqueda = $conexion->prepare('INSERT INTO users (usuario, contrasenya, email)
                        VALUES (:nick, :contrasenya, :mail);'); //Prepara la transacción para crear nuevo usuario
                    $busqueda->bindParam(':nick', $_POST['nick']);
                    $busqueda->bindParam(':contrasenya', $contrasenya);
                    $busqueda->bindParam(':mail', $_POST['mail']);
                    $busqueda->execute();
                    $_SESSION['user']=$conexion->lastInsertId();//Abrir sesión
                    unset($contrasenya);
                } catch (PDOException $trans) {
                    $conexion->rollback();
                    echo '<p class="error">Ha habido un error en la creación de usuario, inténtelo más tarde</p>';
                }
            }
            unset($busqueda); //Cerrar la conexión con la base de datos
            unset($conexion);
        } catch (PDOException $e) {
            echo '<p class="error">Error con la base de datos, por favor, inténtelo más tarde</p>';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <!--Nombre de la pestaña-->
    <title>Revels</title>
    <!--Metadatos-->
    <meta charset="utf-8" name="Author: Enrique Sanz López">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--Enlace al CSS-->
    <link rel="stylesheet" href="css/estiloBase.css">
    <link href="img/R.ico" rel="icon">
</head>

<body>
    <?php
    include_once('inc/cabecera.inc.php');
    if (!isset($_SESSION['user'])) { //No se ha iniciado sesión
        require_once('inc/navegacionOff.inc.php');
        echo '<section>
        <article>
        <h2>¡Bienvenido a Revels!,<br>
        ¡Únete a nuestra comunidad!</h2>
        <form action="#" method="post">
            <label for="nick">Nombre: </label>
            <input type="text" name="nick" id="nick"><br>
            <label for="mail">E-Mail: </label>
            <input type="text" name="mail" id="mail"><br>
            <label for="contrasenya">Contraseña: </label>
            <input type="text" name="contrasenya" id="contrasenya"><br>
            <label for="rcontrasenya">Repite la contraseña: </label>
            <input type="text" name="rcontrasenya" id="rcontrasenya"><br>
            <button type="submit">Crear usuario</button>
        </form>
        </article>
        </section>';
    } else { //Se ha iniciado sesión
        require_once('inc/navegacionOn.inc.php');
        echo '<section>';
        require_once('inc/aside.inc.php'); //Mostrar los usuarios seguidos
        echo '<article>'; //Mostrar todas las revels del usuario, y de todos los usuarios a los que sigue
        try {
            $conexion = new PDO('mysql:host=localhost;dbname=revels', 'revel', 'lever'); //Conectar con la base de datos
            $seguidos=$conexion->query('SELECT userfollowed FROM follows WHERE userid='.$_SESSION['user'].';');
            $cadena='SELECT * FROM revels WHERE userid IN ('.$_SESSION['user'];
            while ($registro=$seguidos->fetch(PDO::FETCH_ASSOC)) {
                $cadena=$cadena.','.$registro['userfollowed'];
            }
            $cadena=$cadena.') ORDER BY fecha DESC;';
            $propias=$conexion->query($cadena);
            if ($propias->rowCount()==0) {
                echo '<h2>No hay ninguna revel publicada</h2>';
            } else {
                echo '<ul>';
                foreach ($propias->fetchAll(PDO::FETCH_ASSOC) as $fila) {//Mostrar mis propios revels
                    $comentarios=$conexion->query('SELECT count(id) FROM comments WHERE revelid='.$fila['id'].';');
                    $nombre=$conexion->query('SELECT usuario FROM users u
                        INNER JOIN revels r
                            ON r.userid=u.id
                        WHERE r.id='.$fila['id'].';');
                    echo '<li><a href="revel.php?id='.$fila['id'].'" alt="Enlace a revel roto">Usuario: '.($nombre->fetch(PDO::FETCH_COLUMN, 0)).'<br>
                    '.$fila['texto'].'<br>
                    Fecha: '.$fila['fecha'].'<br>
                    Comentarios: '.($comentarios->fetch(PDO::FETCH_COLUMN, 0)).'
                    </a></li>';
                }
                echo '</ul>';
            }
            unset($fila); //Cerrar la conexion con la base datos
            unset($comentarios);
            unset($propias);
            unset($conexion);
        } catch (PDOException $e) { //Si no se consigue hacer la query
            echo $e->getMessage();
            echo '<p class="error">Ha habido un fallo en la base de datos, no se pueden ver las revels</p>';
        }
        echo '</article></section>';
    }
    ?>
</body>

</html>