<?php
session_start();
if (!isset($_SESSION['user'])) { //Si no se ha iniciado sesión o se ha entrado incorrectamente, se redirige a index
    header('Location: index.php');
    exit();
}
if (isset($_POST['revel'])) {
    if (!preg_match('/[a-z0-9]{1,}/i', $_POST['revel'])) { //El revel está vacío
        echo '<p class="error">La revel no puede estar vacía</p>';
    } else { //Se tiene que crear el revel
        try {
            $conexion = new PDO('mysql:host=localhost;dbname=revels', 'revel', 'lever'); //Conectar con la base de datos
            $subir = $conexion->prepare('INSERT INTO revels (userid, texto) VALUES (:usuario, :revel);'); //Guardar la revel en la base de datos
            $subir->bindParam(':usuario', $_SESSION['user']);
            $subir->bindParam(':revel', $_POST['revel']);
            $subir->execute();
            $id = $conexion->lastInsertId(); //Conseguir el id del revel
            unset($subir); //Cerrar la conexión con la base de datos
            unset($conexion);
            header('Location: revel.php?id=' . $id); //Redirigir a la página de la revel
            exit();
        } catch (PDOException $e) { //Fallo con la base de datos
            echo '<p class="error">No se ha logrado subir el revel, por favor, inténtelo más tarde</p>';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <!--Nombre de la pestaña-->
    <title>New</title>
    <!--Metadatos-->
    <meta charset="utf-8" name="Author: Enrique Sanz López">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--Enlace al CSS-->
    <link rel="stylesheet" href="css/estiloBase.css">
    <link href="img/R.ico" rel="icon">
</head>

<body>
    <?php
    require_once('inc/cabecera.inc.php');
    require_once('inc/navegacionOn.inc.php');
    ?>
    <section>
        <?php
        require_once('inc/aside.inc.php');
        ?>
        <article>
            <h2>Escribe tu propia revel</h2>
            <form action="#" method="post">
                <label for="texto">Texto: </label><br>
                <textarea id="revel" name="revel"></textarea><br>
                <!--Asumo que el usuario puede llegar a escribir varias líneas en su revel por lo que un textarea es más apropiado que un input de texto-->
                <button type="text">Submit</button>
            </form>
        </article>
    </section>
</body>

</html>