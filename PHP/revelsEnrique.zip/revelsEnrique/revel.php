<?php
session_start();
if (!isset($_SESSION['user']) or !isset($_GET['id'])) {//Si no se ha iniciado sesión o se ha entrado incorrectamente, se redirige a index
    header('Location: index.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <!--Nombre de la pestaña-->
    <title>Revel</title>
    <!--Metadatos-->
    <meta charset="utf-8" name="Author: Enrique Sanz López">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--Enlace al CSS-->
    <link rel="stylesheet" href="css/estiloBase.css">
    <link href="img/R.ico" rel="icon">
</head>

<body>
    <?php
    require_once('inc/cabecera.inc.php');
    require_once('inc/navegacionOn.inc.php');
    echo '<section>';
    require_once('inc/aside.inc.php');//Incluir los usuarios seguidos
    try {
        $conexion=new PDO('mysql:host=localhost;dbname=revels', 'revel', 'lever');//Conectar con la base de datos
        $revel=$conexion->prepare('SELECT * FROM revels WHERE id=:codigo;');
        $revel->bindParam(':codigo', $_GET['id']);
        $revel->execute();
        echo '<article>';
        foreach ($revel->fetchAll(PDO::FETCH_ASSOC) as $fila) {
            $usuario=$conexion->query('SELECT usuario FROM users WHERE id='.$fila['userid'].';');//Conseguir al usuario
            echo '<p>Usuario: '.($usuario->fetchAll(PDO::FETCH_ASSOC)[0]['usuario']).'<br>
                '.$fila['texto'].'<br>
                Fecha: '.$fila['fecha'].'</p>';
        }
        echo '<ul>';
        $revel=$conexion->prepare('SELECT * FROM comments WHERE revelid=:id ORDER BY fecha;');
        $revel->bindParam(':id', $_GET['id']);
        $revel->execute();
        foreach ($revel->fetchAll(PDO::FETCH_ASSOC) as $fila) {
            $usuario=$conexion->query('SELECT usuario FROM users WHERE id='.$fila['userid'].';');
            echo '<li>Usuario: '.($usuario->fetch(PDO::FETCH_ASSOC)['usuario']).'<br>
                '.$fila['texto'].'<br>
                Fecha: '.$fila['fecha'].'</li>';
        }
        unset($usuario);//Cerrar la conexión con la base de datos
        unset($fila);
        unset($revel);
        unset($conexion);
        echo '</ul>';
        echo '<form action="comment.php" method="post">
            <input type="hidden" name="revel" id="revel" value="'.$_GET['id'].'">
            <label for="comentario">Comenta: </label><br>
            <textarea name="comentario" id="comentario"></textarea><br>
            <button type="submit">Enviar</button>
            </form>';
        echo '</article>';
    } catch (PDOException $e) {//Fallo con la base de datos
        echo '<p class="error">No se ha podido abrir la revel, inténtelo más tarde</p>';
    }
    echo '</section>';
    ?>
</body>

</html>