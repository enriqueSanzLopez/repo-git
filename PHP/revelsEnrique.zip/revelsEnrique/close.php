<?php
session_start();
if (isset($_SESSION['user'])) {//Si se ha iniciado sesión, destruir la sesión
    session_destroy();
}
header('Location: index.php');//Redireccionar a index con la sesión cerrada y salir de close
exit();
?>