<?php
session_start();//Iniciar sesión
if (isset($_SESSION['user']) and isset($_POST['borrar'])) {//Se ha entrado en la página correctamente
    try {
        $conexion=new PDO('mysql:host=localhost;dbname=revels', 'revel', 'lever');//Conectar con la base de datos
        $existe=$conexion->prepare('SELECT id FROM revels WHERE userid='.$_SESSION['user'].' AND id=:borrar;');//Comprobar si el revel indicado pertenece al usuario indicado
        $existe->bindParam(':borrar', $_POST['borrar']);
        $existe->execute();
        if ($existe->rowCount()!=0) {//El revel pertenece al usuario
            try {
                $conexion->beginTransaction();//Iniciamos transacción, si no se logra, no se elimina nada
                $existe=$conexion->prepare('DELETE FROM comments WHERE revelid=:borrar;');//Borrar todos los comentarios realizados en el revel
                $existe->bindParam(':borrar', $_POST['borrar']);
                $existe->execute();
                $existe=$conexion->prepare('DELETE FROM revels WHERE id=:borrar;');//Eliminar el revel
                $existe->bindParam(':borrar', $_POST['borrar']);
                $existe->execute();
                $conexion->commit();
            } catch (PDOException $e2) {//Si no se logra borrar el revel, se anula toda la transacción
                $conexion->rollback();
            }
            unset($existe);//Cerrar la conexion con la base de datos
            unset($conexion);
        }
    } catch (PDOException $e) {//Si no se logra borrar el revel, se devuelve al listado
        header('Location: list.php');
        exit();
    }
}
header('Location: list.php');
exit();
?>