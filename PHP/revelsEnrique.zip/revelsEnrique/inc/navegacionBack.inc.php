<nav>
    <ul>
        <li>
            <a href="list.php" alt="No se ha podido enlazar con list">Listar revels</a>
        </li>
        <li>
            <a href="close.php" alt="No se ha podido enlazar con close">Cerrar sesión</a>
        </li>
        <li>
            <a href="cancel.php" alt="No se ha podido enlazar con cancel">Borrar sesión</a>
        </li>
    </ul>
</nav>