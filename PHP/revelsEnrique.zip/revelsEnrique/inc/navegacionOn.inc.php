<nav>
    <ul>
        <li>
            <form action="results.php" method="get">
                <input type="text" name="busqueda" id="busqueda">
                <button type="submit">&#128269</button>
            </form>
        </li>
        <li>
            <a href="new.php" alt="No se ha podido enlazar con new">New</a>
        </li>
        <li>
            <a href="account.php" alt="No se ha podido enlazar con account">Account</a>
        </li>
        <li>
            <a href="close.php" alt="No se ha podido enlazar con close">Close</a>
        </li>
    </ul>
</nav>