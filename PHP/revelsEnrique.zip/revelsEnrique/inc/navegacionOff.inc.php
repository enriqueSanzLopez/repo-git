<nav>
    <ul>
        <li>
            <a href="login.php" alt="Fallo en el enlace a Login">Login</a>
        </li>
    </ul>
</nav>