<header>
    <a href="index.php" alt="No se ha podido volver a la pantalla de inicio">
        <img src="img/R.jpg" alt="Imagen de una R rota">
        <h1 id="titulo">Revels</h1>
    </a>
</header>