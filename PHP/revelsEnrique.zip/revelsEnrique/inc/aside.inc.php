<?php
echo '<aside>';
if (isset($_POST['fborrar'])) {//Se quiere dejar de seguir a un usuario
    try {
        $conexion = new PDO('mysql:host=localhost;dbname=revels', 'revel', 'lever');//Conectarse a la base de datos
        $fborrar=$conexion->prepare('DELETE FROM follows WHERE userid='.$_SESSION['user'].' AND userfollowed=:id;');//Dejar de seguir al usuario indicado
        $fborrar->bindParam(':id', $_POST['fborrar']);
        $fborrar->execute();
        unset($fborrar);//Cerrar la conexión con l abase de datos
        unset($conexion);
    } catch (PDOException $e) {//Falla la base de datos
        echo '<p class="error">No se ha podido dejar de seguir al usuario, inténtelo más tarde</p>';
    }
}
try {
    $conexion=new PDO('mysql:host=localhost;dbname=revels', 'revel', 'lever');//Conectar con la base de datos
    $consulta=$conexion->prepare('SELECT id, usuario FROM users u 
        INNER JOIN follows f
            ON f.userfollowed=u.id
        WHERE f.userid=:sesion;');//Extraer de la base de datos todos los usuarios que sigue el usuario
    $consulta->bindParam(':sesion', $_SESSION['user']);
    $consulta->execute();
    if ($consulta->rowCount()==0) {
        echo '<h2>No estás siguiendo a nadie</h2>';
    } else {
        echo '<ul>';
        foreach ($consulta->fetchAll(PDO::FETCH_ASSOC) as $fila) {
            echo '<li><form action="#" method="post">
            '.$fila['usuario'].'
                <input type="hidden" id="fborrar" name="fborrar" value="'.$fila['id'].'">
                <button type="submit">Dejar de seguir</button>
            </form></li>';//Mostrar todos los nicks de usuarios seguidos con un botón para dejar de seguirlos
        }
    }
    unset($fila);//Cerrar la conexión con la base de datos
    unset($consulta);
    unset($conexion);
    echo '</ul>';
} catch (PDOException $e) {//En caso de que falle la consulta con la base de datos
    echo '<p class="error">Ha habido un fallo en la base de datos, no se pueden ver los usuarios seguidos</p>';
}
echo '</aside>';
?>