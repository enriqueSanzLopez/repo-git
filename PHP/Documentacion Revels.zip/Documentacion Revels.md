﻿**Enrique Sanz López 2º DAW**

Objetivos del proyecto

El objetivo de este proyecto es crear una red social llamada revels que permitirá a los usuarios crear sesión, iniciarla, cerrarla y borrarla. Poder generar y borrar tus propias publicaciones, comentar publicaciones, así como ver los comentarios dejados por otros usuarios en tus publicaciones, y seguir a otros usuarios para ver lo que publican.

Todas las páginas de la aplicación compartirán un mismo estilo que se adaptará al tipo de pantalla en el que se abra la aplicación para garantizar la accesibilidad.

Para lograr estas funcionalidades, se emplearán los lenguajes de programación y marcado PHP, CSS, HTML, y MySQL, alojando la aplicación en un servidor apache para comprobar su correcto funcionamiento.

Los archivos HTML del proyecto se generan usando archivos PHP, para así poder adaptar las páginas a los cambios en la base de datos y a las peticiones del usuario. Además, se ha especificado que para las páginas account.php, list.php, y delete.php, se empleará un estilo distinto que contraste con el del resto de la aplicación.

La aplicación se compondrá de las siguientes archivos que ejecutan las diferentes funcionalidades del proyecto:

- **index.php:** en caso de que el usuario no haya iniciado sesión, mostrará un formulario para crear un nuevo usuario de la aplicación, y si se ha iniciado sesión, funcionará como la página de inicio de la cuenta del usuario.
- **new.php:** mostrará un formulario para introducir revels nuevos.
- **results.php:** muestra a los usuarios que coinciden con la búsqueda del formulario de navegación.
- **revel.php:** mostrará la revelación cuyo id reciba y todos los comentarios asociados a dicha revelación, así mismo, también mostrará un formulario para introducir nuevos comentarios.
- **close.php:** archivo encargado de cerrar la sesión y retornar a index.php sin la sesión iniciada. No muestra nada visualmente, dado que al terminar el proceso de cerrar sesión retorna a index.
- **comment.php:** valida los datos recibidos del formulario de revel.php, los introduce en la base de datos, y devuelve a la página revel.
- **login.php:** muestra un formulario para iniciar sesión al usuario, valida los datos del formulario, y si todo es correcto, devuelve al usuario a index.php con la sesión iniciada.
- **account.php:** mostrará un formulario que permite que el usuario actualice los datos de su cuenta.
- **cancel.php:** mostrará un formulario para que el usuario confirme si quiere borrar su cuenta, y en caso de que éste acepte, se eliminará la cuenta y se redirigirá a index.php sin tener la sesión iniciada.
- **list.php:** mostrará una lista de todas las revels publicadas por el usuario junto a un botón para eliminar cada una.
- **delete.php:** eliminará una revel con todos los comentarios asociados a ella.
- **cabecera.inc.php:** archivo que se incluye en todos los archivos php destinados a mostrar contenido al usuario, solo genera la cabecera.
- **navegacionOff.inc.php:** archivo que se incluye en todos los archivos php destinados a mostrar contenido al usuario que no ha iniciado sesión, genera una barra de navegación que solo muestra un enlace a login.
- **navegacionOn.inc.php:** archivo que se incluye en todos los archivos php destinados a mostrar contenido al usuario que ha iniciado sesión, genera una barra de navegación con enlaces a las páginas de new.php, account.php, y close.php, además, contiene un formulario de búsqueda que cuando se envía, manda al usuario a results.php.
- **navegacionBack.inc.php:** archivo que se incluye en todos los archivos php destinados a mostrar contenido al usuario que ha iniciado sesión y que sirven para la gestión de la cuenta, genera una barra de navegación con enlaces a list.php, close.php, y cancel.php. En las páginas en las que se aplica este archivo, este sustituye a navegacionOn.inc.php.
- **aside.inc.php:** archivo que se incluye en todos los archivos php destinados a mostrar contenido al usuario que ha iniciado sesión, genera una barra lateral en la que se muestra una lista de usuarios seguidos junto con botones para dejar de seguir.
- **estiloBase.css:** archivo que determina los estilos de la aplicación tanto en sesión iniciada como sin iniciar sesión.
- **estiloBack.css:** archivo que determina los estilos de la aplicación en las páginas de account.php, y list.php.

Conforme se desarrolle la aplicación, se irá comprobando el correcto funcionamiento de cada uno de los archivos ya indicados mediante el uso de datos correctos e incorrectos en los formularios para comprobar que ejecuta todas las validaciones correctamente, y en caso de introducir datos correctos realiza las funcionalidades ya especificadas anteriormente. Así mismo, se probará a realizar SQL inject en los diferentes campos de formularios para comprobar que la aplicación es resistente a este tipo de ataques.

Estructura y diseño

Como ya se ha visto en el apartado anterior, es requisito de la aplicación garantizar que esta pueda ser usada con comodidad en cualquier tipo de pantalla, para lo cual es necesario garantizar que todas las páginas tengan un diseño responsivo que sea capaz de adaptarse a cualquier tipo de pantalla. Para esto se ha hecho uso de flexbox y de media queries para que los anchos y la distribución de la página se adapten a los diferentes tipos de pantalla. A continuación se pueden observar las maquetaciones de las diferentes páginas para diferentes tipos de pantallas para entender cómo se distribuiría cada página de la aplicación en cada caso.

![](Aspose.Words.62bd1ca3-1f09-48d3-a323-c756938ed99f.001.png)

***Imagen 1: account, index sin tener la sesión iniciada, new, y login para pantalla de ordenador***

![](Aspose.Words.62bd1ca3-1f09-48d3-a323-c756938ed99f.002.png)

***Imagen 2: account, index sin la sesión iniciada, new, y login para pantalla de tablet***

![](Aspose.Words.62bd1ca3-1f09-48d3-a323-c756938ed99f.003.png)

***Imagen 3: account, index sin la sesión iniciada, new y login para pantalla de móvil***

![](Aspose.Words.62bd1ca3-1f09-48d3-a323-c756938ed99f.004.png)

***Imagen 4: index con la sesión encendida para pantalla de ordenador***

![](Aspose.Words.62bd1ca3-1f09-48d3-a323-c756938ed99f.005.png)

***Imagen 5: index con la sesión iniciada para pantalla de tablet***

![](Aspose.Words.62bd1ca3-1f09-48d3-a323-c756938ed99f.006.png)

***Imagen 6: index con la sesión iniciada para pantalla de móvil***

![](Aspose.Words.62bd1ca3-1f09-48d3-a323-c756938ed99f.007.png)

***Imagen 7: revel para pantalla de ordenador***

![](Aspose.Words.62bd1ca3-1f09-48d3-a323-c756938ed99f.008.png)

***Imagen 8: revel para pantalla de tablet***

![](Aspose.Words.62bd1ca3-1f09-48d3-a323-c756938ed99f.009.png)

***Imagen 9: revel para pantalla de móvil***

![](Aspose.Words.62bd1ca3-1f09-48d3-a323-c756938ed99f.010.png)

***Imagen 10: results para pantalla de ordenador***

![](Aspose.Words.62bd1ca3-1f09-48d3-a323-c756938ed99f.011.png)

***Imagen 11: results para pantalla de tablet***

![](Aspose.Words.62bd1ca3-1f09-48d3-a323-c756938ed99f.012.png)

***Imagen 12: results para pantalla de móvil***

![](Aspose.Words.62bd1ca3-1f09-48d3-a323-c756938ed99f.013.png)

***Imagen 13: cancel para pantalla de ordenador***

![](Aspose.Words.62bd1ca3-1f09-48d3-a323-c756938ed99f.014.png)

***Imagen 14: cancel para pantalla de tablet***

![](Aspose.Words.62bd1ca3-1f09-48d3-a323-c756938ed99f.015.png)

***Imagen 15: cancel para pantalla de móvil***

![](Aspose.Words.62bd1ca3-1f09-48d3-a323-c756938ed99f.016.png)

***Imagen 16: list para pantalla de ordenador***

![](Aspose.Words.62bd1ca3-1f09-48d3-a323-c756938ed99f.017.png)

***Imagen 17: list para pantalla de tablet***

![](Aspose.Words.62bd1ca3-1f09-48d3-a323-c756938ed99f.018.png)

***Imagen 18: list para pantalla de móvil***

Contenido

Los formularios usarán inputs de texto y botones para envíar datos al servidor por petición de la compañía para así poder comprobar la validación de datos por parte del servidor, con la excepción del formulario de borrado de cuenta, el cual incluirá un input de checkbox que el usuario tendrá que rellenar para confirmar el borrado de su cuenta. Las revels serán artículos de texto que incluirán el usuario que los emplea, el contenido del artículo, la fecha de publicación del mismo, y los comentarios hechos por los usuarios sobre el mismo.

La navegación, en caso de no haber abierto sesión, solo permitirá el acceso a la página de login, mientras que si se ha abierto sesión, quitará el enlace a login, y contendrá en su lugar un formulario de búsqueda que envía a results, un enlace para cerrar sesión, un enlace al formulario de generación de revels, y un enlace a los detalles de la cuenta, si se encuentra en los detalles de la cuenta, el usuario tendrá acceso a un enlace de cierre de sesión, y un enlace a borrado de sesión.

La cabecera, además de incluir el icono y el nombre de la aplicación, servirá como enlace a la página index de la aplicación.

Además de los componentes mencionados anteriormente, cuando se haya iniciado sesión, las páginas también incluirán una barra lateral en cuyo interior se encuentre un listado de los usuarios a los que se está siguiendo junto a un botón para dejar de seguir al usuario.

Guía de estilos

El objetivo del estilo de la aplicación es el de transmitir la sensación de que es una web dinámica, pero profesional, para lo cual se ha usado el color rojo para el fondo de navegación y el color del título, mientras que para el resto de la página se usa el color blanco y el color de los apartados de la navegación, resaltando de esta forma la navegación y el título con respecto al resto de la página, facilitando de esta manera que el usuario vea rápidamente las diferentes secciones de la página a las que puede acceder en todo momento. Además, se ha usado un color rgb(211, 211, 211) como fondo para los formularios para que estos resalten con respecto al resto de la página, mientras que los botones usan un color de fondo rgb(240, 128, 128) para tener un estilos más asemejarse al de la navegación, cuando se hace click en los botones de los formularios, estos pasan a tener un color de fondo rojo. Por otra parte, para las páginas que anteriormente ya hemos mencionado que necesitan un estilo diferente, se ha decidido optar por un tono rgb(0, 0, 255) para la navegación para dar un tono más serio a la página, ya que en estas páginas es donde uno puede generar cambios en su cuenta y necesita un tono más formal.

La gama de colores usada en la aplicación ha sido:

- rgb(255, 0, 0), para el texto de la cabecera, el fondo de la navegación, y el logotipo de la aplicación.
- rgb(255, 255, 255), para el texto de la navegación, y el texto de los botones
- rgb(211, 211, 211), para el fondo de los formularios.
- rgb(250, 240, 230), para cuando se pasa por encima de las diferentes entradas de datos de los formularios.
- rgb(240, 128, 128), para el fondo de los botones.
- rgb(0, 0, 255), para el fondo de la navegación en las páginas account.php, cancel.php, y list.php.

Como fuente para la aplicación se ha empleado la fuente Times New Roman, la cual pertenece a la familia Serif, ya que esta da un tono formal al texto y es muy legible. Se ha optado por esta fuente y no por otras porque aunque la aplicación quiere dar una impresión de dinamismo, no se desea que se pierda la sensación de que es una web profesional, por lo que se ha dado más importancia a mantener un tipo conocido, fácil de leer, y que se use en entornos formales como la prensa.

Iconografía, tono y terminología

Para el diseño del icono de la aplicación, se ha buscado un diseño que haga uso de los colores principales de la página y que haga referencia al nombre de la página, para que cuando el usuario la vea, piense en revels. Por ello, se ha decidido hacer uso de la inicial de la aplicación, en un color rojo sobre fondo blanco como podemos observar a continuación.

![](Aspose.Words.62bd1ca3-1f09-48d3-a323-c756938ed99f.019.png)

***Imagen 19: Icono de Revels***

Este icono será usado en todas las cabeceras de la aplicación, así como en futuras campañas de publicidad para la página.

En toda la aplicación se hace uso de un tono informal, para dar una sensación amigable a los usuarios y facilitar que estos inicien temas de conversación.

Por último, se hace uso del término revel para referirse a los artículos publicados por los usuarios.

Código CSS y muestra con HTML

Para el diseño de la página se han empleado dos estilos, uno para la parte frontal de la página, y el otro para las páginas de ajustes de la cuenta. Esto ha llevado a la necesidad de usar dos archivos CSS, llamados estiloBase.css y estiloBack.css. Los códigos de estos archivos se verán a continuación, y más tarde, ejemplos de su uso en diferentes páginas de la aplicación y para diferentes tamaños.

**Archivo estiloBase.css:**

/\*Tamaños para móvil y estilo general\*/

header a{/\*Enlace de cabecera como contenedor flexbox en línea para ver la imagen al lado del título\*/

padding: 5px;

display: flex;

flex-direction: row;

flex-wrap: wrap;

justify-content: left;

}

header a>h1,

h2 {/\*Texto del título en color rojo y centrado, ligeramente distanciado del borde de la caja\*/

text-align: center;

color: red;

padding: 5px;

}

header a>h1,

header a:hover>h1,

header a:visited>h1 {/\*Como el título es un enlace, eliminar la decoración de este y el cambio de color\*/

color: red;

}

nav ul {/\*Convertir la navegación en una caja flex, poner los componentes de lista en línea, alinearlos a la derecha, separarlos ligeramente, y poner un fondo rojo acorde con el título y el icono de la aplicación\*/

display: flex;

flex-direction: row;

flex-wrap: wrap;

justify-content: right;

padding: 5px;

background: red;

}

ul li {/\*Eliminar la decoración de los elementos de lista, separarlos ligeramente, y alinear el contenido de cada elemento al centro de su caja\*/

list-style-type: none;

padding: 10px;

text-align: center;

}

nav ul li a,

nav ul li a:visited {/\*Letras de los elementos de lista en blanco y sin subrayado\*/

color: white;

}

nav ul li a:hover {/\*Cuando se pasa por encima de los elementos de la lista, se subraya el elemento\*/

text-decoration: underline;

}

section {/\*Centrar los elementos de la sección principal de la página como una fila\*/

display: flex;

flex-direction: row;

flex-wrap: wrap;

justify-content: center;

height: 70vh;

}

aside {/\*Centrar los elementos de usuarios seguidos como una columna, y usar un fondo negro con letras en blanco\*/

display: flex;

flex-direction: column;

flex-wrap: nowrap;

align-content: center;

background: black;

color: white;

padding: 5px;

}

section article>form, section article>ul {/\*Los formularios cuyos padres sean la sección tendrán un fondo gris y un poco de espacio\*/

padding: 5px;

background: lightgray;

}

label {/\*Alinear el formulario\*/

display: inline-block;

width: 20%;

}

button {/\*Los botones tendrán letras en blanco y un fondo lightcoral\*/

width: fit-content;

color: white;

background-color: lightcoral;

border-radius: 3px;

padding: 5px;

}

button:hover {/\*Cuando se pase por el botón, este pasará a tener un fondo rojo\*/

background-color: red;

}

input, textarea {

width: 100vw;

margin-top: 2.5px;

margin-bottom: 2.5px;

}

aside {

width: 100vw;

}

article {

flex: 1;

width: 100vw;

padding: 5px;

}

a{

text-decoration: none;

color: black;

}

.error{

color: red;

}

aside{

flex: 1;

width: 100%;

text-align: center;

padding: 5px;

}

/\*Media queries de para el diseño responsivo abajo\*/

@media only screen and (min-width: 550px) {

/\*Tamaño para tablet\*/

aside {

width: 20vw; }

article {

width: 50vw; }

aside {

width: 40vw; }

input, textarea {

width: 90%; }

}

@media only screen and (min-width: 768px) {

/\*Tamaño PC\*/

aside {

width: 20vw; }

article {

width: 50vw; }

aside {

width: 40vw; }

input, textarea {

width: 70%; }

}

**Archivo estiloBack.css:**

/\*Tamaños para móvil y estilo general\*/

header a{/\*Enlace de cabecera como contenedor flexbox en línea para ver la imagen al lado del título\*/

padding: 5px;

display: flex;

flex-direction: row;

flex-wrap: wrap;

justify-content: left;

}

header a>h1,

h2 {/\*Texto del título en color rojo y centrado, ligeramente distanciado del borde de la caja\*/

text-align: center;

color: blue;

padding: 5px;

}

header a>h1,

header a:hover>h1,

header a:visited>h1 {/\*Como el título es un enlace, eliminar la decoración de este y el cambio de color\*/

color: red;

}

nav ul {/\*Convertir la navegación en una caja flex, poner los componentes de lista en línea, alinearlos a la derecha, separarlos ligeramente, y poner un fondo rojo acorde con el título y el icono de la aplicación\*/

display: flex;

flex-direction: row;

flex-wrap: wrap;

justify-content: right;

padding: 5px;

background: blue;

}

ul li {/\*Eliminar la decoración de los elementos de lista, separarlos ligeramente, y alinear el contenido de cada elemento al centro de su caja\*/

list-style-type: none;

padding: 10px;

text-align: center;

}

nav ul li a,

nav ul li a:visited {/\*Letras de los elementos de lista en blanco y sin subrayado\*/

color: white;

}

nav ul li a:hover {/\*Cuando se pasa por encima de los elementos de la lista, se subraya el elemento\*/

text-decoration: underline;

}

section {/\*Centrar los elementos de la sección principal de la página como una fila\*/

display: flex;

flex-direction: row;

flex-wrap: wrap;

justify-content: center;

height: 70vh;

}

aside {/\*Centrar los elementos de usuarios seguidos como una columna, y usar un fondo negro con letras en blanco\*/

display: flex;

flex-direction: column;

flex-wrap: nowrap;

align-content: center;

background: black;

color: white;

padding: 5px;

}

section article>form, section article>ul {/\*Los formularios cuyos padres sean la sección tendrán un fondo gris y un poco de espacio\*/

padding: 5px;

background: lightgray;

}

label {/\*Alinear el formulario\*/

display: inline-block;

width: 20%;

}

button {/\*Los botones tendrán letras en blanco y un fondo lightcoral\*/

width: fit-content;

color: white;

background-color: lightcoral;

border-radius: 3px;

padding: 5px;

}

button:hover {/\*Cuando se pase por el botón, este pasará a tener un fondo rojo\*/

background-color: blue;

}

input, textarea {

width: 100vw;

margin-top: 2.5px;

margin-bottom: 2.5px;

}

aside {

width: 100vw;

}

article {

flex: 1;

width: 100vw;

padding: 5px;

}

a{

text-decoration: none;

}

.error{

color: blue;

}

aside{

flex: 1;

width: 100%;

text-align: center;

padding: 5px;

}

#aceptar{

width: 10px;

color: red;

}

/\*Media queries de para el diseño responsivo abajo\*/ @media only screen and (min-width: 550px) {

/\*Tamaño para tablet\*/

aside {

width: 20vw; }

article {

width: 50vw; }

aside {

width: 40vw; }

input, textarea {

width: 90%; }

}

@media only screen and (min-width: 768px) {

/\*Tamaño PC\*/

aside {

width: 20vw; }

article {

width: 50vw; }

aside {

width: 40vw; }

input, textarea {

width: 70%; }

}

Por otra parte, este es el resultado que dan en diferentes páginas de la aplicación:

![](Aspose.Words.62bd1ca3-1f09-48d3-a323-c756938ed99f.020.jpeg)

***Imagen 20: index.php con sesión iniciada para pantallas de ordenador***

![](Aspose.Words.62bd1ca3-1f09-48d3-a323-c756938ed99f.021.jpeg)

***Imagen 21: index.php con sesión iniciada para pantallas de ordenador***

![](Aspose.Words.62bd1ca3-1f09-48d3-a323-c756938ed99f.022.jpeg)

***Imagen 22: index.php con sesión iniciada para pantallas de móvil***

![](Aspose.Words.62bd1ca3-1f09-48d3-a323-c756938ed99f.023.jpeg)

***Imagen 23: account.php para pantallas de ordenador***

![](Aspose.Words.62bd1ca3-1f09-48d3-a323-c756938ed99f.024.jpeg)

***Imagen 24: account.php para pantallas de tablet***

![](Aspose.Words.62bd1ca3-1f09-48d3-a323-c756938ed99f.025.jpeg)

***Imagen 25: account.php para pantallas de móvil***
