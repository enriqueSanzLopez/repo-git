<!DOCTYPE html>
<html lang="es">

<head>
    <!--Nombre de la pestaña-->
    <title>altaEnrique</title>
    <!--Metadatos-->
    <meta charset="utf-8" name="Author: Enrique Sanz López">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="expires" content="Sat, 07 feb 2016 00:00:00 GMT">
    <!--Enlace al CSS-->
    <link rel="stylesheet" href="css/estilo.css">
</head>

<body>
    <?php
    function muestraCartas (string $jugador, int $numero, $mano) {
        echo '<section><h3>Jugador '.$numero.': '.$jugador.'</h3><arcticle class="mano">';
        for ($i=0;$i<count($mano);$i++) {
            echo '<img src="baraja/'.$mano[$i]['imagen'].'" alt="Imagen de carta con el valor '.$mano[$i]['valor'].'">';
        }
        echo '</article></section>';
    }
    function puntosFiguras ($valor) {
        if ($valor=='J') {
            $valor=10;
        } else if ($valor=='Q') {
            $valor=11;
        }else if ($valor=='K') {
            $valor=12;
        }
        return $valor;
    }
    ?>
    <?php
    //Declarar la baraja
    echo '<header><h1>Las cartas mas altas<h1></header>';
    include_once ('inc/navegacion.inc.php');
    $cartas = [["palo" => "corazones", "valor" => "1", "imagen" => "cor_1.png"],
    ["palo" => "corazones", "valor" =>"2", "imagen" => "cor_2.png"],
    ["palo" => "corazones", "valor" =>"3", "imagen" => "cor_3.png"],
    ["palo" => "corazones", "valor" =>"4", "imagen" => "cor_4.png"],
    ["palo" => "corazones", "valor" =>"5", "imagen" => "cor_5.png"],
    ["palo" => "corazones", "valor" =>"6", "imagen" => "cor_6.png"],
    ["palo" => "corazones", "valor" =>"7", "imagen" => "cor_7.png"],
    ["palo" => "corazones", "valor" =>"8", "imagen" => "cor_8.png"],
    ["palo" => "corazones", "valor" =>"9", "imagen" => "cor_9.png"],
    ["palo" => "corazones", "valor" =>"10", "imagen" => "cor_10.png"],
    ["palo" => "corazones", "valor" =>"J", "imagen" => "cor_j.png"],
    ["palo" => "corazones", "valor" =>"Q", "imagen" => "cor_q.png"],
    ["palo" => "corazones", "valor" =>"K", "imagen" => "cor_k.png"],
    ["palo" => "picas", "valor" => "1", "imagen" => "pic_1.png"],
    ["palo" => "picas", "valor" =>"2", "imagen" => "pic_2.png"],
    ["palo" => "picas", "valor" =>"3", "imagen" => "pic_3.png"],
    ["palo" => "picas", "valor" =>"4", "imagen" => "pic_4.png"],
    ["palo" => "picas", "valor" =>"5", "imagen" => "pic_5.png"],
    ["palo" => "picas", "valor" =>"6", "imagen" => "pic_6.png"],
    ["palo" => "picas", "valor" =>"7", "imagen" => "pic_7.png"],
    ["palo" => "picas", "valor" =>"8", "imagen" => "pic_8.png"],
    ["palo" => "picas", "valor" =>"9", "imagen" => "pic_9.png"],
    ["palo" => "picas", "valor" =>"10", "imagen" => "pic_10.png"],
    ["palo" => "picas", "valor" =>"J", "imagen" => "pic_j.png"],
    ["palo" => "picas", "valor" =>"Q", "imagen" => "pic_q.png"],
    ["palo" => "picas", "valor" =>"K", "imagen" => "pic_k.png"],
    ["palo" => "rombos", "valor" => "1", "imagen" => "rom_1.png"],
    ["palo" => "rombos", "valor" =>"2", "imagen" => "rom_2.png"],
    ["palo" => "rombos", "valor" =>"3", "imagen" => "rom_3.png"],
    ["palo" => "rombos", "valor" =>"4", "imagen" => "rom_4.png"],
    ["palo" => "rombos", "valor" =>"5", "imagen" => "rom_5.png"],
    ["palo" => "rombos", "valor" =>"6", "imagen" => "rom_6.png"],
    ["palo" => "rombos", "valor" =>"7", "imagen" => "rom_7.png"],
    ["palo" => "rombos", "valor" =>"8", "imagen" => "rom_8.png"],
    ["palo" => "rombos", "valor" =>"9", "imagen" => "rom_9.png"],
    ["palo" => "rombos", "valor" =>"10", "imagen" => "rom_10.png"],
    ["palo" => "rombos", "valor" =>"J", "imagen" => "rom_j.png"],
    ["palo" => "rombos", "valor" =>"Q", "imagen" => "rom_q.png"],
    ["palo" => "rombos", "valor" =>"K", "imagen" => "rom_k.png"],
    ["palo" => "trevoles", "valor" => "1", "imagen" => "rom_1.png"],
    ["palo" => "trevoles", "valor" =>"2", "imagen" => "rom_2.png"],
    ["palo" => "trevoles", "valor" =>"3", "imagen" => "rom_3.png"],
    ["palo" => "trevoles", "valor" =>"4", "imagen" => "rom_4.png"],
    ["palo" => "trevoles", "valor" =>"5", "imagen" => "rom_5.png"],
    ["palo" => "trevoles", "valor" =>"6", "imagen" => "rom_6.png"],
    ["palo" => "trevoles", "valor" =>"7", "imagen" => "rom_7.png"],
    ["palo" => "trevoles", "valor" =>"8", "imagen" => "rom_8.png"],
    ["palo" => "trevoles", "valor" =>"9", "imagen" => "rom_9.png"],
    ["palo" => "trevoles", "valor" =>"10", "imagen" => "rom_10.png"],
    ["palo" => "trevoles", "valor" =>"J", "imagen" => "rom_j.png"],
    ["palo" => "trevoles", "valor" =>"Q", "imagen" => "rom_q.png"],
    ["palo" => "trevoles", "valor" =>"K", "imagen" => "rom_k.png"]];
    shuffle($cartas);//Ordenar aleatoriamente
    $jugador1='Tomás';//Declarar jugadores
    $jugador2='Ana';
    $puntos1=0;
    $puntos2=0;
    for ($i=0;$i<10;$i++) {//Sacar las cartas de cada jugador
        $mano1[$i]=array_shift($cartas);
        $mano2[$i]=array_shift($cartas);//Comparar a quien se le asigna punto
        $valor1=$mano1[$i]['valor'];
        $valor2=$mano2[$i]['valor'];
        $valor1=puntosFiguras ($valor1);
        $valor2=puntosFiguras ($valor2);
        if ($valor1<$valor2) {
            $puntos2+=2;
        } else if ($valor1>$valor2) {
            $puntos1+=2;
        } else {
            $puntos1+=1;
            $puntos2+=1;
        }
    }
    muestraCartas ($jugador1, 1, $mano1);
    muestraCartas ($jugador2, 2, $mano2);
    echo '<section><h4>Resultado de la partida:</h4><p>'.$jugador1.': '.$puntos1.'</p><p>'.$jugador2.': '.$puntos2.'</p>';
    if ($puntos1<$puntos2) {
        echo '<p>Ganador: '.$jugador2.'</p></section>';
    } else if ($puntos1>$puntos2) {
            echo '<p>Ganador: '.$jugador1.'</p></section>';
    } else {
        echo '<p>Ganador: Empate</p></section>';
    }
    ?>
</body>

</html>