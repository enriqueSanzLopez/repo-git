<!DOCTYPE html>
<html lang="es">

<head>
    <!--Nombre de la pestaña-->
    <title>juego21Enrique</title>
    <!--Metadatos-->
    <meta charset="utf-8" name="Author: Enrique Sanz López">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="expires" content="Sat, 07 feb 2016 00:00:00 GMT">
    <!--Enlace al CSS-->
    <link rel="stylesheet" href="css/estilo.css">
</head>

<body>
    <header><h1>Black Jack</h1></header>
    <?php
    include_once('inc/navegacion.inc.php');
    function figuraNumero ($valor) :int {
        if ($valor=='J' or $valor=='Q' or $valor=='K') {
            $valor=10;//Pasar a valor con el que se pueda operar
        }
        return $valor;
    }
    function numeroAses ($mano) :int {
        $ases=0;
        for ($i=0;$i<count($mano);$i++) {
            if ($mano[$i]['valor']==1) {
                $ases+=1;
            }
        }
        return $ases;
    }
    ?>
    <?php
    //Declarar la baraja
    $cartas = [["palo" => "corazones", "valor" => "1", "imagen" => "cor_1.png"],
    ["palo" => "corazones", "valor" =>"2", "imagen" => "cor_2.png"],
    ["palo" => "corazones", "valor" =>"3", "imagen" => "cor_3.png"],
    ["palo" => "corazones", "valor" =>"4", "imagen" => "cor_4.png"],
    ["palo" => "corazones", "valor" =>"5", "imagen" => "cor_5.png"],
    ["palo" => "corazones", "valor" =>"6", "imagen" => "cor_6.png"],
    ["palo" => "corazones", "valor" =>"7", "imagen" => "cor_7.png"],
    ["palo" => "corazones", "valor" =>"8", "imagen" => "cor_8.png"],
    ["palo" => "corazones", "valor" =>"9", "imagen" => "cor_9.png"],
    ["palo" => "corazones", "valor" =>"10", "imagen" => "cor_10.png"],
    ["palo" => "corazones", "valor" =>"J", "imagen" => "cor_j.png"],
    ["palo" => "corazones", "valor" =>"Q", "imagen" => "cor_q.png"],
    ["palo" => "corazones", "valor" =>"K", "imagen" => "cor_k.png"],
    ["palo" => "picas", "valor" => "1", "imagen" => "pic_1.png"],
    ["palo" => "picas", "valor" =>"2", "imagen" => "pic_2.png"],
    ["palo" => "picas", "valor" =>"3", "imagen" => "pic_3.png"],
    ["palo" => "picas", "valor" =>"4", "imagen" => "pic_4.png"],
    ["palo" => "picas", "valor" =>"5", "imagen" => "pic_5.png"],
    ["palo" => "picas", "valor" =>"6", "imagen" => "pic_6.png"],
    ["palo" => "picas", "valor" =>"7", "imagen" => "pic_7.png"],
    ["palo" => "picas", "valor" =>"8", "imagen" => "pic_8.png"],
    ["palo" => "picas", "valor" =>"9", "imagen" => "pic_9.png"],
    ["palo" => "picas", "valor" =>"10", "imagen" => "pic_10.png"],
    ["palo" => "picas", "valor" =>"J", "imagen" => "pic_j.png"],
    ["palo" => "picas", "valor" =>"Q", "imagen" => "pic_q.png"],
    ["palo" => "picas", "valor" =>"K", "imagen" => "pic_k.png"],
    ["palo" => "rombos", "valor" => "1", "imagen" => "rom_1.png"],
    ["palo" => "rombos", "valor" =>"2", "imagen" => "rom_2.png"],
    ["palo" => "rombos", "valor" =>"3", "imagen" => "rom_3.png"],
    ["palo" => "rombos", "valor" =>"4", "imagen" => "rom_4.png"],
    ["palo" => "rombos", "valor" =>"5", "imagen" => "rom_5.png"],
    ["palo" => "rombos", "valor" =>"6", "imagen" => "rom_6.png"],
    ["palo" => "rombos", "valor" =>"7", "imagen" => "rom_7.png"],
    ["palo" => "rombos", "valor" =>"8", "imagen" => "rom_8.png"],
    ["palo" => "rombos", "valor" =>"9", "imagen" => "rom_9.png"],
    ["palo" => "rombos", "valor" =>"10", "imagen" => "rom_10.png"],
    ["palo" => "rombos", "valor" =>"J", "imagen" => "rom_j.png"],
    ["palo" => "rombos", "valor" =>"Q", "imagen" => "rom_q.png"],
    ["palo" => "rombos", "valor" =>"K", "imagen" => "rom_k.png"],
    ["palo" => "trevoles", "valor" => "1", "imagen" => "rom_1.png"],
    ["palo" => "trevoles", "valor" =>"2", "imagen" => "rom_2.png"],
    ["palo" => "trevoles", "valor" =>"3", "imagen" => "rom_3.png"],
    ["palo" => "trevoles", "valor" =>"4", "imagen" => "rom_4.png"],
    ["palo" => "trevoles", "valor" =>"5", "imagen" => "rom_5.png"],
    ["palo" => "trevoles", "valor" =>"6", "imagen" => "rom_6.png"],
    ["palo" => "trevoles", "valor" =>"7", "imagen" => "rom_7.png"],
    ["palo" => "trevoles", "valor" =>"8", "imagen" => "rom_8.png"],
    ["palo" => "trevoles", "valor" =>"9", "imagen" => "rom_9.png"],
    ["palo" => "trevoles", "valor" =>"10", "imagen" => "rom_10.png"],
    ["palo" => "trevoles", "valor" =>"J", "imagen" => "rom_j.png"],
    ["palo" => "trevoles", "valor" =>"Q", "imagen" => "rom_q.png"],
    ["palo" => "trevoles", "valor" =>"K", "imagen" => "rom_k.png"]];
    shuffle($cartas);//Ordenar aleatoriamente
    $jugadores=['Banca', 'Rick', 'Morty', 'Summer', 'Jerry', 'Beth'];//Declarar jugadores
    $jugadores=array_flip($jugadores);//Invertir claves y valores
    for ($i=0;$i<2;$i++) {//Repetir 2 veces
        foreach ($jugadores as $clave => $numero) {
            $mano[$clave][]=array_shift($cartas);//Sacar una carta para cada jugador
        }
    }
    foreach ($mano as $nombre => $sacadas) {//Calcular las puntuaciones iniciales de cada jugador
        $sacadas[0]['valor']=figuraNumero($sacadas[0]['valor']);//Pasar las figuras a valor 10
        $sacadas[1]['valor']=figuraNumero($sacadas[1]['valor']);
        $ases=numeroAses($sacadas);//Averiguar el numero de ases
        $puntos[$nombre]=$sacadas[0]['valor']+$sacadas[1]['valor'];//Sacar la puntuacion actual
        for ($i=0;$i<$ases;$i++) {
            if ($puntos[$nombre]<=11) {
                $puntos[$nombre]+=10;//Si hay ases disponibles y no te pasas le sumas 10
            } else{//Si te pasas sales del bucle
                break;
            }
        }
        while ($puntos[$nombre]<14) {//Comprobar si el jugador pide otra carta
            $mano[$nombre][]=array_shift($cartas);
            $mano[$nombre][count($mano[$nombre])-1]['valor']=figuraNumero($mano[$nombre][count($mano[$nombre])-1]['valor']);
            $puntos[$nombre]+=$mano[$nombre][count($mano[$nombre])-1]['valor'];//Sumar valor
            if ($mano[$nombre][count($mano[$nombre])-1]['valor']==1 and $puntos<=11) {//Si la ultima carta es un as y la puntuacion hasta ese punto es menor que 11, sumale 10
                $puntos[$nombre]+=10;
            }
        }
    }
    echo '<section class="sinBorde">';//Mostrar a la banca
    echo '<article><h2>Jugador 0: Banca</h2>';
    foreach ($mano['Banca'] as $valor) {
        echo '<img src="baraja/'.$valor['imagen'].'" alt="Imagen de carta con el valor '.$valor['imagen'].'">';
    }
    echo '<p>Puntos: '.$puntos['Banca'].'</p></article>';
    $contador=0;
    foreach ($mano as $jugador => $resultados) {//Mostrar al resto de jugadores
        if ($jugador=='Banca') {
            continue;
        }
        $contador+=1;
        echo '<article><h2>Jugador '.$contador.': '.$jugador.'</h2>';
        foreach ($mano[$jugador] as $valor) {
            echo '<img src="baraja/'.$valor['imagen'].'" alt="Imagen de carta con el valor '.$valor['imagen'].'">';
        }
        echo '';
        if ($puntos[$jugador]>21) {//El jugador se ha pasado de 21
            echo '<p>Puntos: '.$puntos[$jugador].'- ¡PIERDE!</p>';
        }else if ($puntos[$jugador]>$puntos['Banca']) {//El jugador ha superado a la banca sin pasarse de 21
            echo '<p>Puntos: '.$puntos[$jugador].'- ¡GANA!</p>';
        }else if ($puntos['Banca']>21) {//La banca se ha pasado y el jugador no
            echo '<p>Puntos: '.$puntos[$jugador].'- ¡GANA!</p>';
        } else if ($puntos[$jugador]==$puntos['Banca']) {//La banca y el jugador han sacado lo mismo y ninguno se ha pasado de 21
            echo '<p>Puntos: '.$puntos[$jugador].'- ¡EMPATE!</p>';
        } else {//El jugador ha sacado menos que la banca y la banca no se ha pasado de 21
            echo '<p>Puntos: '.$puntos[$jugador].'- ¡PIERDE!</p>';
        }
        echo '</article>';
    }
    echo '</section>';
    ?>
</body>

</html>