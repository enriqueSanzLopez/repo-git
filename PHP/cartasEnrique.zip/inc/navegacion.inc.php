<h2>Enrique Sanz López</h2>
<nav>
        <ul>
            <li><a href="index.php" alt="Enlace roto">Inicio</a></li>
            <li><a href="altaEnrique.php" alt="Enlace roto">Carta mas alta</a></li>
            <li><a href="juego21Enrique.php" alt="Enlace roto">21</a></li>
        </ul>
</nav>