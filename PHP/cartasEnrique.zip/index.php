<!DOCTYPE html>
<html lang="es">

<head>
    <!--Nombre de la pestaña-->
    <title>Inicio</title>
    <!--Metadatos-->
    <meta charset="utf-8" name="Author: Enrique Sanz López">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="expires" content="Sat, 07 feb 2016 00:00:00 GMT">
    <!--Enlace al CSS-->
    <link rel="stylesheet" href="css/estilo.css">
</head>

<body>
    <header><h1>Bienvenido a los juegos de cartas</h1></header>
    <?php
    include_once('inc/navegacion.inc.php');//Incluir la navegacion
    ?>
    <img src="baraja/baraja.jpeg" alt="Imagen de una baraja" id="baraja">
</body>

</html>