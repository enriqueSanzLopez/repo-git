drop database if exists futbol;
create database futbol;
use futbol;

create table player(
	player_id INT PRIMARY KEY auto_increment,
    name_player VARCHAR(50) NOT NULL,
    surname varchar(50) NOT NULL,
    birth_date DATE NOT NULL
    );

create table team(
	team_id INT PRIMARY KEY auto_increment,
    name_team VARCHAR(50) NOT NULL,
    acronym varchar(3) NOT NULL,
    city varchar(50) NOT NULL
    );
    
create table season(
	season_id INT PRIMARY KEY auto_increment,
    year_start INT NOT NULL,
    year_end INT NOT NULL
    );

create table player_team_season(
	player_id INT NOT NULL,
    team_id INT NOT NULL,
    season_id INT NOT NULL,
    primary key(player_id, team_id, season_id),
    foreign key(player_id)references player(player_id),
    foreign key (team_id)references team(team_id),
    foreign key (season_id)references season(season_id)
    );
    
create table league(
	league_id INT PRIMARY KEY auto_increment,
    name_team varchar(50) not null,
    season_id int not null,
    foreign key(season_id)references season(season_id)
    );
    
create table season(
	team_id int,
    league_id int,
    primary key(team_id, league_id),
    foreign key(team_id)references team(team_id),
    foreign key(league_id)references league(league_id)
    );

create table stats(
	stats_id INT primary key auto_increment,
    goals int not null,
    shots int not null,
    goal_shots int not null,
    corners int not null
    );

create table game(
	game_id int primary key auto_increment,
    league_id int not null,
    local_team_id int not null,
    guest_team_id int not null,
    local_stats_id int not null,
    guest_stats_id int not null,
    foreign key(league_id)references league(league_id),
    foreign key(local_team_id)references team(team_id),
    foreign key(guest_team_id)references team(team_id),
    foreign key(local_stats_id)references stats(stats_id),
    foreign key(guest_stats_id)references stats(stats_id)
    );