drop database if exists Cine;
create database Cine;
use Cine;

create table pais(
	cod_pais int primary key auto_increment,
    nombre varchar(50) not null
    );

create table genero(
	cod_gen int primary key auto_increment,
    nombre varchar(50) not null
    );

create table libro_peli(
	cod_lib int primary key auto_increment,
    titulo varchar(50) not null,
    anyo date not null,
    autor varchar(50) not null
    );

create table actor(
	cod_act int primary key auto_increment,
    nombre varchar(50) not null,
    fecha_nac date not null,
    cod_pais int,
    foreign key(cod_pais)references pais(cod_pais)
    );
    
create table pelicula(
	cod_peli int primary key auto_increment,
    titulo varchar(50) not null,
    anyo date not null,
    duracion time not null,
    director varchar (50) not null,
    cod_lib int,
    foreign key(cod_lib)references libro_peli(cod_lib)
    );

create table actua(
	papel varchar(50) not null,
    cod_act int,
    cod_peli int,
    primary key(cod_act, cod_peli),
    foreign key(cod_act)references actor(cod_act),
    foreign key(cod_peli)references pelicula(cod_peli)
    );

create table clasificacion(
	cod_gen int,
    cod_peli int,
    primary key(cod_gen, cod_peli),
    foreign key(cod_gen)references genero(cod_gen),
    foreign key(cod_peli)references pelicula(cod_peli)
    );