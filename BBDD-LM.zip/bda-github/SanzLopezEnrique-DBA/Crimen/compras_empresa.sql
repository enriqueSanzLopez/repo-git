use crimen;

select *
from compres;