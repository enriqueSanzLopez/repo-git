use crimen;

select *
from trucades;