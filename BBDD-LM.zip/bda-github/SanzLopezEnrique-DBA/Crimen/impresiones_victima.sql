use crimen;

select *
from impresions_victima;