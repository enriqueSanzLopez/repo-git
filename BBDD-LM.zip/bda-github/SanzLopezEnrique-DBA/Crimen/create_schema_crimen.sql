drop database if exists crimen;
create database crimen;
use crimen;

-- CREACIÓ DE TAULES

CREATE TABLE IF NOT EXISTS departaments (
        id serial PRIMARY KEY,
        nom varchar(25) NOT NULL );


CREATE TABLE IF NOT EXISTS empleats (
	id serial PRIMARY KEY,
	nom varchar(20) NOT NULL,
	cognom1 varchar(20) NOT NULL,
	cognom2 varchar(20) NOT NULL,
	sou int,
	telefon varchar(15) UNIQUE,
	dept  integer REFERENCES departaments (id),
	carrec varchar(25),
	address text );

CREATE TABLE IF NOT EXISTS compres (
	id serial PRIMARY KEY,
	dept integer REFERENCES departaments (id),
	isbn text NOT NULL );


CREATE TABLE IF NOT EXISTS trucades (
        id serial PRIMARY KEY,
        origen varchar(15) REFERENCES empleats (telefon),
        desti varchar(15) NOT NULL,
	hora_inici TIMESTAMP,
	hora_fi TIMESTAMP);

CREATE TABLE IF NOT EXISTS fitxatges (
        hora TIMESTAMP NOT NULL,
        empleat integer NOT NULL REFERENCES empleats (id),
        PRIMARY KEY(hora, empleat));

CREATE TABLE IF NOT EXISTS evidencies_policia (
	empleat integer PRIMARY KEY REFERENCES empleats(id),
	testimoni varchar(50),
	evidencia text );

CREATE TABLE IF NOT EXISTS impresions_victima (
        hora timestamp PRIMARY KEY,
        document varchar(250) NOT NULL,
        descripcio text );

CREATE TABLE IF NOT EXISTS agenda (
        hora timestamp PRIMARY KEY,
        descripcio text NOT NULL );
