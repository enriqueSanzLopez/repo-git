use crimen;

select d.*
from departaments d
inner join empleats e
	on e.dept=d.id
where e.nom="Leonard" and e.cognom1="Cameron";