use crimen;

select *
from agenda;