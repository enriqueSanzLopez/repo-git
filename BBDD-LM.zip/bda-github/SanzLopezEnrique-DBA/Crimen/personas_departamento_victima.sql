use crimen;

select e.*
from empleats e
inner join departaments d
	on e.dept=d.id
where d.id=2;