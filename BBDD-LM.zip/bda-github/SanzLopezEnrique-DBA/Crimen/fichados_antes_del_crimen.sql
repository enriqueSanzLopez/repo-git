use crimen;

select distinct e.nom, e.cognom1, f.hora, d.nom
from empleats e
inner join departaments d
	on e.dept=d.id
inner join fitxatges f
	on f.empleat=e.id
where f.hora>='2020-10-16 18:07';