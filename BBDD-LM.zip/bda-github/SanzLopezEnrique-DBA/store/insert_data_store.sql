use store;

/*Tabla cashiers*/
insert into cashiers(id, `name`, surname, section, centre, ubication)
values (1, 'Jaume', 'González', 'Disseny', 12203, 'CAT');
insert into cashiers(id, `name`, surname, section, centre, ubication)
values (2, 'Elisabeth', 'Alcázar', 'Informàtica', 18890, 'VAL');
insert into cashiers(id, `name`, surname, section, centre, ubication)
values (3, 'Erin', 'Vera', 'Llar', 19901, 'CAN');
insert into cashiers(id, `name`, surname, section, centre, ubication)
values (4, 'Glòria', 'Olivares', 'Llar', 18890, 'VAL');
insert into cashiers(id, `name`, surname, section, centre, ubication)
values (5, 'Abigail', 'Colina', 'Manualitats', 12203, 'CAT');
insert into cashiers(id, `name`, surname, section, centre, ubication)
values (6, 'Carlos', 'Pérez', 'Viatges', 19901, 'CAN');

/*Tabla products*/
insert into products(id, `description`, price)
values (12203, 'La voz de los dioses. Trudi Canavan', 21.90);
insert into products(id, `description`, price)
values (13340, 'Shadows in the Night. Bob Dylan', 9.19);
insert into products(id, `description`, price)
values (15440, 'Windsor MI-1001. Trompeta en si bemol', 126.12);

/*Tabla vending_machines*/
insert into vending_machines(id, floor)
values (68779, 1);
insert into vending_machines(id, floor)
values (35099, 7);
insert into vending_machines(id, floor)
values (93276, 12);
insert into vending_machines(id, floor)
values (62755, 0);

/*Tabla sales*/
insert into sales(cashier, vending_machine, product)
values (1, 68779, 12203);
insert into sales(cashier, vending_machine, product)
values (2, 35099, 12203);
insert into sales(cashier, vending_machine, product)
values (5, 62755, 15440);
insert into sales(cashier, vending_machine, product)
values (6, 62755, 13340);

/*Mostrar la tabla x*/
/*select * from sales;*/