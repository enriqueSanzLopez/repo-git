use store;
/*Bloquear el check de foreign key*/
set foreign_key_checks=0;
/*id de cashier con autoincrement*/
alter table cashiers
modify column id int auto_increment;
/*Restaurar el check de foreign key*/
set foreign_key_checks=1;
/*surname mandatory con string de hasta 100 caracteres*/
alter table cashiers
modify column surname varchar(100) not null check(binary left(upper(surname),1)=left(surname,1));
/*centre mandatory positive and superior to 0*/
alter table cashiers
modify column centre int not null check (centre>0);
/*Incluir numero de telefono en cashiers con comentario*/
alter table cashiers
add column phone_number varchar(12) after ubication;
/*Hacer description de products mandatory*/
alter table products
modify column `description` varchar(150) not null;
/*Incluir un valor por defecto para price de products e incluir comentarios*/
alter table products
modify column price decimal(7,2) comment 'Price in €' default 0.0 not null;