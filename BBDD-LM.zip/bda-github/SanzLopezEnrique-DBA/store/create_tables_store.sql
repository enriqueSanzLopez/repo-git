drop database if exists store;
create database store;
use store;

create table cashiers(
	/*The attributes may be changed if the teacher changes the
    pdf*/
    /*I assume the code of the cashier would be created automatically
    by the database, but as it is no showed in the statement, I won't
    write it*/
    id int primary key,
    /*Name of the cashier*/
    `name` varchar(50) not null check(binary left(upper(`name`),1)=left(`name`,1)),
    surname varchar(50) null check(binary left(upper(surname),1)=left(surname,1)),
    section varchar(50),
    centre int not null,
    /*Checking that the whole data is uppercase*/
    ubication varchar(3) not null check (binary upper(ubication)=ubication)
    );

create table products(
	/*The attributes may be changed if the teacher changes the
    pdf*/
    id int primary key,
    `description` varchar(150),
    price decimal(7,2) not null check(price>0)
    );

create table vending_machines(
	/*The attributes may be changed if the teacher changes the
    pdf*/
    id int primary key,
    floor int
    );

create table sales(
	/*The attributes may be changed if the teacher changes the
    pdf*/
    cashier int,
    vending_machine int,
    product int,
    primary key(cashier, vending_machine, product),
    constraint cash foreign key(cashier)references cashiers(id) on delete cascade,
    constraint mach foreign key(vending_machine)references vending_machines(id) on delete cascade,
    constraint prod foreign key(product)references products(id) on delete cascade
    );