use store;
/*Comprobar constraints*/
/*Cashier primary key*/
insert into cashiers(id, `name`, surname, section, centre, ubication)
values (1, 'Jaume', 'González', 'Disseny', 12203, 'CAT');
insert into cashiers(id, `name`, surname, section, centre, ubication)
values (1, 'Marcos', 'González', 'Disseny', 12203, 'CAT');
/*Cashier name first letter uppercase*/
insert into cashiers(id, `name`, surname, section, centre, ubication)
values (7, 'jaume', 'González', 'Disseny', 12203, 'CAT');
/*Cashier surname first letter uppercase*/
insert into cashiers(id, `name`, surname, section, centre, ubication)
values (8, 'Jaume', 'gonzález', 'Disseny', 12203, 'CAT');
/*Cashier ubication uppercase*/
insert into cashiers(id, `name`, surname, section, centre, ubication)
values (9, 'Jaume', 'González', 'Disseny', 12203, 'cat');
/*Product mandatory price*/
insert into products(id, `description`, price)
values (12204, 'La voz de los dioses. Trudi Canavan', null);
/*Product positive sell price*/
insert into products(id, `description`, price)
values (12205, 'La voz de los dioses. Trudi Canavan', -21.90);
/*Sale primary key usando una primary key ya usada*/
insert into sales(cashier, vending_machine, product)
values (1, 68779, 12203);
/*Sale cashier foreign key*/
insert into sales(cashier, vending_machine, product)
values (10, 68779, 12203);