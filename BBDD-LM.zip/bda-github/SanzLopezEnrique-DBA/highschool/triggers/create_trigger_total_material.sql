use highschool;
delimiter //
create trigger insert_material
	after insert on material
    for each row
    begin
		update total_material set amount=amount+new.amount;
    end; //
delimiter ;

delimiter //
create trigger update_material
	after update on material
    for each row
    begin
		update total_material set amount=amount+new.amount-old.amount;
    end; //
delimiter ;

delimiter //
create trigger delete_material
	after delete on material
    for each row
    begin
		update total_material set amount=amount-old.amount;
    end; //
delimiter ;