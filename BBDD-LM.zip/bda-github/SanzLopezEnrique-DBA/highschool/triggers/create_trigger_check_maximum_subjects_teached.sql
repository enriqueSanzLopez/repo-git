use highschool;

delimiter //
create trigger subjects_teached
	before insert on teaches
    for each row
    begin
		declare num_horas int;
        select sum(s.hours)/33 into num_horas
        from teaches t
        inner join `subject` s
			on s.subject_id=t.subject_id
		where t.teacherDNI=new.teacherDNI and t.year=new.year;
        if num_horas<=18 then
			signal sqlstate '45000'
            set message_text='El profesor imparte demasiadas horas';
        end if;
    end; //
delimiter ;