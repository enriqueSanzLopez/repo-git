use highschool;

create table total_material(
	amount int unsigned default 0
    );

insert into total_material (amount) values(0);