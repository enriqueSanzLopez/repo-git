use highschool;

drop trigger if exists check_maximum_students_group;
drop trigger if exists check_maximum_students_group2;

delimiter //
create trigger check_maximum_students_group
	before insert on student
    for each row
    begin
		declare numero int;
        declare acronimo varchar(6);
        declare mensaje text;
        select count(DNI) into numero
        from student
        where course_id=new.course_id and group_letter=new.group_letter;
        select c.acronym into acronimo
        from course c
        where c.course_id=new.course_id;
        if numero>=10 then
			set mensaje=concat("The group ", "\"", acronimo, "-", new.group_letter, "\"", " can't have more than 10 students");
            signal sqlstate '45000'
            set message_text=mensaje;
        end if;
    end; //
delimiter ;

delimiter //
create trigger check_maximum_students_group2
	before update on student
    for each row
    begin
		declare numero int;
        declare acronimo varchar(6);
        declare mensaje text;
        select count(DNI) into numero
        from student
        where course_id=new.course_id and group_letter=new.group_letter;
        select c.acronym into acronimo
        from course c
        where c.course_id=new.course_id;
        if numero>=10 then
			set mensaje=concat("The group ", "\"", acronimo, "-", new.group_letter, "\"", " can't have more than 10 students");
            signal sqlstate '45000'
            set message_text=mensaje;
        end if;
    end; //
delimiter ;
