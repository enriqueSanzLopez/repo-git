use highschool;

delimiter //
create trigger passed_subject
	before insert on enrolled
    for each row
    begin
		declare nota decimal(4,2);
        select max(grade) into nota
        from enrolled
        where studentDNI=new.studentDNI and year<new.year and subject_id=new.subject_id;
        if nota>=5 then
			signal sqlstate '45000'
            set message_text='El alumno ya ha aprobado esa materia';
        end if;
    end; //
delimiter ;