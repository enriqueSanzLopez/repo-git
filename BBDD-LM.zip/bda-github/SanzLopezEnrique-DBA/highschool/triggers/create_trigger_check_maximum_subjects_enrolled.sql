use highschool;

delimiter //
create trigger check_maximum_subjects_enrolled
	before insert on enrolled
    for each row
    begin
		declare num_materias int;
        select count(*) into num_materias
        from enrolled
        where studentDNI=new.studentDNI and year=new.year;
        if num_materias>6 then
			signal sqlstate '45000'
            set message_text='El alumno no puede matricularse en más de 6 materias';
        end if;
    end; //
delimiter ;