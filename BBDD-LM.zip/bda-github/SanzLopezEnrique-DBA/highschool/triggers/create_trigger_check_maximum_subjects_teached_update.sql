use highschool;

drop trigger if exists maximum_subjects_teached_update;

delimiter //
create trigger maximum_subjects_teached_update
	before update on teaches
    for each row
begin
	declare horastotal decimal(4,2);
    declare horas_viejas decimal(4,2);
    declare horas_nuevas decimal(4,2);
    declare mensaje text;
    declare total decimal(4,2);
    /*Horas totales del profesor*/
    select sum(s.hours)/33 into horastotal
    from `subject` s
    inner join teaches t
		on s.subject_id=t.subject_id
	where t.teacherDNI=new.teacherDNI and t.`year`=new.`year`;
    /*Horas viejas*/
    select hours/33 into horas_viejas
    from `subject`
    where subject_id=old.subject_id;
    /*Horas nuevas*/
    select hours/33 into horas_nuevas
    from `subject`
    where subject_id=new.subject_id;
    if (horastotal-horas_viejas+horas_nuevas)>18 then
		set total=horastotal-horas_viejas+horas_nuevas;
		set mensaje=concat("The teacher \"", new.teacherDNI, "\" can't teach the subject \"", new.subject_id, "\" since the total weekly hours would be \"", total, "\"");
        signal sqlstate '45000'
        set message_text=mensaje;
    end if;
end; //
delimiter ;