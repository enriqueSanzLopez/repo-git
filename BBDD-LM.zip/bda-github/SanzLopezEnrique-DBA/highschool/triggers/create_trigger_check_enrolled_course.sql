use highschool;

/*Crear un trigger para que un estudiante no pueda inscribirse
en nada que no pertenezca a su curso*/
delimiter //
create trigger enrolled_course
	before insert on enrolled
    for each row
    begin
        declare curso_materia int;
        declare curso_alumno int;
        /*Conseguir el curso al que pertenece la materia*/
        select c.course_id into curso_materia
        from course c
        inner join `subject` s
			on c.course_id=s.course_id
		inner join enrolled e
			on s.subject_id=e.subject_id
		where e.subject_id=new.subject_id and e.studentDNI=new.DNI;
        /*Conseguir el curso al que pertenece el alumno*/
        select c.course_id into curso_alumno
        from course c
        inner join student s
			on s.course_id=c.course_id
		inner join enrolled e
			on e.studentDNI=s.DNI
		where e.studentDNI=new.DNI and e.subject_id=new.subject_id;
        /*Comparar curso de la materia con el curso del estudiante*/
        if curso_alumno!=curso_materia then
			signal sqlstate '45000'
            set message_text='El alumno no pertenece al curso de esta materia';
        end if;
    end; //
delimiter ;