use highschool;

drop procedure if exists split_group;

delimiter //
create procedure split_group(
	in course_acronym varchar(5),
    in letter char)
not deterministic
begin
    declare nletter type of letter;
    declare ngroup int;
    declare curso int;
    declare ntutor varchar(10);
	set autocommit=0;
    start transaction;
    /*Conseguir la id del curso*/
    select g.course_id into curso
    from `group` g
    inner join course c
		on c.course_id=g.course_id
	where g.letter=letter and c.acronym=course_acronym;
    /*Comenzamos la transaccion
    Conseguir la letra del nuevo grupo*/
    select char(ascii(max(g.letter))+1) into nletter
    from `group` g
    where g.course_id=curso;
    /*Conseguir el DNI del tutor del nuevo grupo*/
    select t.DNI into ntutor
        from teacher t
        inner join teaches ts
			on ts.teacherDNI=t.DNI
		inner join `subject` s
			on s.subject_id=ts.subject_id
		inner join course c
			on c.course_id=s.course_id and c.course_id=curso
		group by t.DNI
		having t.DNI not in (
			select tutorDNI
			from `group`
		) and t.DNI in (
        select t.DNI
        from teacher t
        inner join teaches ts
			on ts.teacherDNI=t.DNI
		inner join `subject` s
			on ts.subject_id=s.subject_id
		group by t.DNI
        having (sum(s.hours)/33)<18)
        order by sum(s.hours) desc
        limit 1;
	/*Si no hay ningún profesor que reuna los requisitos
    buscar un profesor que no sea tutor*/
	if ntutor is null then
		select t.DNI into ntutor
        from teacher t
        where t.DNI not in (
			select tutorDNI
            from `group`)
        limit 1;
    end if;
    /*Averiguar el numero de integrantes del grupo*/
    select count(*)/2 into ngroup
    from student
    where course_id=curso and group_letter=letter;
    /*Crear grupo*/
    insert into `group` (course_id, letter, tutorDNI) values
    (curso, nletter, ntutor);
    savepoint nuevo_grupo_creado;
    /*Dividir grupo*/
    update student
    set group_letter=nletter
    where course_id=curso and group_letter=letter
    order by DNI desc
    limit ngroup;
    /*limit limita el número de salidas,
    y offset inicia las salidas a partir de determinado
    punto*/
    commit;
    set autocommit=1;
end; //
delimiter ;