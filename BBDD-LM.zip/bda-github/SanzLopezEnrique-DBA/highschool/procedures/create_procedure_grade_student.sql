use highschool;

drop procedure if exists grade_student;

delimiter //
create procedure grade_student(
	in studentDNI varchar(10),
    in subject_id varchar(4),
    in grade int,
    in `year`int)
not deterministic
begin
	set autocommit=0;
	start transaction;
    if exists(select *
		from enrolled e
        where e.studentDNI=studentDNI and e.subject_id=subject_id and e.`year`=`year`) then
        select *
		from enrolled e
        where e.studentDNI=studentDNI and e.subject_id=subject_id and e.`year`=`year` for update;
        /*Existe luego actualizamos*/
        update enrolled e
        set e.grade=grade
        where e.studentDNI=studentDNI and e.subject_id=subject_id and e.`year`=`year`;
    else
		/*No existe por lo que insertamos*/
        insert into enrolled (studentDNI, subject_id, `year`, grade)
        values (studentDNI, subject_id, `year`, grade);
    end if;
    commit;
	set autocommit=1;
end; //
delimiter ;