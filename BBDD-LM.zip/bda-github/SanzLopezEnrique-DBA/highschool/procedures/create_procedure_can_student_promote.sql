use highschool;

drop procedure if exists can_student_promote;

delimiter //
create procedure can_student_promote(
	in DNI varchar(10),
    in `year` int,
    out puede boolean
    )
not deterministic
begin
	/*Declarar créditos*/
	declare total int;
    declare conseguidos int;
    /*Declarar el curso del alumno*/
    declare curso int;
    /*Obtener curso*/
    select c.course_id into curso
    from course c
    inner join student s
		on s.course_id=c.course_id
	where s.DNI=DNI;
    /*Averiguar los créditos que hay en el curso del alumno*/
    select sum(s.ects) into total
    from `subject` s
    inner join enrolled e
		on e.subject_id=s.subject_id
	inner join student st
		on st.DNI=e.studentDNI
	where e.studentDNI=DNI and s.course_id=curso and e.`year`=`year`;
    /*Averiguar los créditos superados por el alumno*/
    select sum(s.ects) into conseguidos
    from `subject` s
    inner join enrolled e
		on e.subject_id=s.subject_id
	inner join student st
		on st.DNI=e.studentDNI
	where e.studentDNI=DNI and e.`year`=`year` and s.course_id=curso and e.grade>=5;
    if (conseguidos/total)*100<80 then
		set puede=false;
	else
		set puede=true;
	end if;
end; //
delimiter ;