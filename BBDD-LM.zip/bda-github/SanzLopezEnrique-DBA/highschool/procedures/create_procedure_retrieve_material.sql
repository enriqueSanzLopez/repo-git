use highschool;

drop procedure if exists retrieve_material;

delimiter //

create procedure retrieve_material (
	in teacherDNI varchar(10),
	in material_id int,
    in amount int)
not deterministic
begin
	declare available_amount type of material.amount;
    /*Desactivamos el commmit*/
	set autocommit=0;
    start transaction;
    select material.amount into available_amount
    from material
    where material.material_id=material_id for update;/*Bloquear la tabla de materiales*/
    if available_amount >= amount then
		/*Hay una cantidad suficiente*/
        savepoint suficientes;
        update material
        set material.amount=material.amount-amount
        where material.material_id=material_id;
        /*Modificar el historial*/
        insert into material_history (material_id, teacherDNI, amount) values
        (material_id, teacherDNI, amount);
	elseif available_amount>0 then
		/*Se sacan los que se pueden*/
        savepoint insuficientes;
        update material
        set material.amount=0
        where material.material_id=material_id;
        /*Modificar*/
        insert into material_history (material_id, teacherDNI, amount) values
        (material_id, teacherDNI, available_amount);
	end if;
    /*Terminamos la transacción*/
    commit;
    /*Reactivamos el commit*/
    set autocommit=1;
end; //
delimiter ;