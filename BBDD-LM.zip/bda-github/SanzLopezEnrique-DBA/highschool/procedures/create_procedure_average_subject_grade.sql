use highschool;

drop procedure if exists average_subject_grade;

delimiter //
create procedure average_subject_grade (
    in subject_id varchar(4),
	in `year` int,
    out resultado decimal(4,2)
    )
not deterministic
begin
    /*Averiguar la nota promedio y guardarlo en la salida*/
    select avg(grade) into resultado
    from enrolled e
    where e.subject_id=subject_id and e.`year`=`year`;
end; //
delimiter ;