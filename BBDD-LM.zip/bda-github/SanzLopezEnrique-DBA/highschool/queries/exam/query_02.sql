use highschool;

select DNI dni, name, surname
from person
where surname like "S%" and surname like "%E%";