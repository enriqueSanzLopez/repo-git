use highschool;

select s.DNI DNI, p.name name, p.surname surname, s.group_letter group_letter
from student s
inner join person p
	on p.DNI=s.DNI
inner join course c
	on c.course_id=s.course_id
where c.acronym="ASIX"
order by s.DNI asc;