use highschool;

select s.subject_id subject_id, s.acronym acronym, s.name name, avg(e.grade) average_grade
from subject s
inner join course c
	on s.course_id=c.course_id
inner join enrolled e
	on e.subject_id=s.subject_id
where c.acronym="DAW" and e.grade>=5
group by s.subject_id;