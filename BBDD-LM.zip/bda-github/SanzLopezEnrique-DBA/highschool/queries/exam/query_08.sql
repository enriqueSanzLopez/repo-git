use highschool;

select c.acronym course, s.subject_id subject_id, s.acronym acronym, s.name name
from course c
inner join subject s
	on s.course_id=c.course_id
inner join enrolled e
	on e.subject_id=s.subject_id
group by s.subject_id
having avg(e.grade)<=ALL(
	select avg(e.grade)
    from enrolled e
    inner join subject s
		on s.subject_id=e.subject_id
	group by s.subject_id
    );