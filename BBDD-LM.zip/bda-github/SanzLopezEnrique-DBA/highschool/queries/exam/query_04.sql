use highschool;

select distinct s.acronym acronym, s.name name, t.DNI teacherDNI
from subject s
inner join course c
	on s.course_id=c.course_id
inner join teaches tc
	on tc.subject_id=s.subject_id
inner join teacher t
	on t.DNI=tc.teacherDNI
where c.acronym="DAW" and tc.year=2021
order by s.acronym asc;