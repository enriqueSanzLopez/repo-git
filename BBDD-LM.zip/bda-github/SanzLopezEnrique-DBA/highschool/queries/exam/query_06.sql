use highschool;

select s.DNI DNI, p.name name, p.surname surname, p.birth_date birth_date
from student s
inner join person p
	on p.DNI=s.DNI
where p.birth_date>=ALL(
	select p.birth_date
    from person p
    inner join student s
		on s.DNI=p.DNI)
order by s.DNI asc;