use highschool;

select distinct s.subject_id subject_id, s.acronym acronym, s.name name
from subject s
inner join enrolled e
	on e.subject_id=s.subject_id
where e.grade>8;