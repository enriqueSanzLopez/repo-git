use highschool;

select c.acronym acronym, s.subject_id subject_id, s.acronym acronym, s.name name
from course c
inner join subject s
	on s.course_id=c.course_id
group by s.subject_id
having s.subject_id  not in (
	select s.subject_id
    from subject s
    inner join enrolled e
		on e.subject_id=s.subject_id
	where e.grade<5
    )
order by s.name asc;