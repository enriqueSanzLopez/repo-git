use highschool;

select acronym, name
from course;