use highschool;

select subject_id, name, hours
from subject
where course_id=1;