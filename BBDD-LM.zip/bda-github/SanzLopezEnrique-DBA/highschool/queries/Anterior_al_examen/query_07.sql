use highschool;

select t.dni, p.name, p.surname
from teacher t
inner join person p
	on t.dni=p.dni;