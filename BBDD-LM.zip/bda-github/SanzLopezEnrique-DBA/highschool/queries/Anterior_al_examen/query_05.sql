use highschool;
/*Gente cuyo apellido comience por M*/
select name, surname, birth_date
from person
where surname like 'M%'
order by birth_date asc;