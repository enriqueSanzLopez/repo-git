use highschool;

select acronym, name, hours
from subject
where hours<100;