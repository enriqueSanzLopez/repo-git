use highschool;

select c.acronym, s.acronym, s.name
from course c
inner join subject s
	on s.course_id=c.course_id;