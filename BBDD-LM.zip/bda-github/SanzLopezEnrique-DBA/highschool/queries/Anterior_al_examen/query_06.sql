use highschool;
/*Ordenar en base a varios atributos*/
select student_dni, subject_id, year_id, grade
from enrolled
where year_id=1
order by subject_id asc, grade desc;