use highschool;

select count(*)
from person;