use highschool;

/*Usando los siguientes comandos de consola, exportamos los datos
deseados desde el servidor:

Con el comando:
mysql -uroot -p1234 -h192.168.56.101 -e "select * from highschool.subject;" | tr "\t" ","  > subjects.csv

Con este comando hemos exportado la tabla subject en al fichero csv subjects.csv y lo hemos guardado en la carpeta que queríamos.

El siguiente caso es volver a importar el fichero subjects.csv en la base de datos.
Para esto tenemos que tener en cuenta que la tabla subjects sigue teniendo todos los
datos que hemos exportado guardados y que debemos reemplazarlos, por lo que el comando
será el siguiente:*/

/*load data local infile "/home/enrlop/Documents/bda-github/SanzLopezEnrique-DBA/highschool/examDCL/subjects.csv" replace
	into table `subject`
	fields terminated by ','
	lines terminated by '\n'
    ignore 1 lines
    (subject_id,course_id,`name`,acronym,hours);*/

/*El ignore 1 lines es para evitar que la importación coja los títulos
de las columnas como datos a introducir en la tabla y para conseguir la
ruta he realizado un pwd en la carpeta donde se encuentra el archivo csv*/

/*Cuando realizamos la importación como se indica arriba, nos da un problema con
los check de las foreign key, por lo que tenemos que desactivarlas temporalmente,
para realizar la importación con éxito*/

/*Desactivar checks foreign key*/
set foreign_key_checks=0;

/*Importar los datos*/
load data local infile "/home/enrlop/Documents/bda-github/SanzLopezEnrique-DBA/highschool/examDCL/subjects.csv" replace
	into table `subject`
	fields terminated by ','
	lines terminated by '\n'
    ignore 1 lines
    (subject_id,course_id,`name`,acronym,hours);

/*Actviar checks foreign key*/
set foreign_key_checks=1;