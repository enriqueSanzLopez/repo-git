use highschool;

create or replace view view_average_grade as
	select concat(c.acronym,"-",g.letter) `group`,
		s.DNI DNI,
		p.surname surname,
		p.`name` `name`,
		avg(e.grade) `avg-grade`
	from person p
	inner join student s
		on s.DNI=p.DNI
	inner join `group` g
		on g.letter=s.group_letter and g.course_id=s.course_id
	inner join course c
		on c.course_id=s.course_id
	inner join enrolled e
		on e.studentDNI=s.DNI
	group by s.DNI
    order by `group` asc, p.surname asc, p.`name` asc, s.DNI asc;