use highschool;

/*Para realizar la transacción indicada, es necesario seleccionar
solo los datos de los alumnos deseados, para lo cual vamos a hacer
un select en el que solo salgan los alumnos a los que se les puede
convalidar FOL*/

/*Comprobar mediante select cuales son los alumnos a los que hay que actualizar*/
select p.`name` `name`,
	p.surname surname,
    s.DNI DNI,
    su.acronym,
    e.grade grade,
    e.`year` año_actual,
    e1.grade nota_anterior,
    e1.`year` año_viejo
from person p
inner join student s
	on p.DNI=s.DNI
inner join enrolled e
	on e.studentDNI=s.DNI
inner join enrolled e1
	on e1.`year`<e.`year` and e1.studentDNI=e.studentDNI
inner join `subject` su
	on su.subject_id=e.subject_id
where e.`year`=2021 and e1.grade>=5 and s.DNI in(
	select s.DNI
    from student s
    inner join enrolled e
		on e.studentDNI=s.DNI and e.grade>=5
	inner join enrolled e1
		on e1.`year`<e.`year`
	inner join `subject` su
		on su.subject_id=e.subject_id
	group by s.DNI
    having count(e.`year`)>1 and su.acronym="FOL"
	);

/*Sabiendo los elementos que tenemos que cambiar, que son las notas
debemos comenzar la transacción y bloquear la tabla de enrolled*/

/*Desactivamos el atucommit*/
set autocommit=0;

/*Comenzamos la transacción*/
start transaction;

/*Bloqueamos enrolled*/
lock table enrolled write;

/*Realizamos la actualización de la tabla, en este caso, como conocemos
los alumnos a los que queremos actualizar, los actualizamos uno por uno*/
update enrolled set grade=5
where studentDNI="25962840A" and `year`=2021;

update enrolled set grade=5
where studentDNI="63665445L" and `year`=2021;

update enrolled set grade=5
where studentDNI="87497335E" and `year`=2021;

/*En caso de no lograr una actualización correcta de las tablas,
aquí es donde se ejecutaría

rollback;

pero en este caso, como hemos terminado la actualización
satisfactoriamente desbloqueamos las tablas*/
unlock tables;

/*Terminamos la transacción*/
commit;

/*Activamos el autocommit*/
set autocommit=1;

/*Y repetimos el select del inicio para comprobar si se ha actualizado
la tabla*/
select p.`name` `name`,
	p.surname surname,
    s.DNI DNI,
    su.acronym,
    e.grade grade,
    e.`year` año_actual,
    e1.grade nota_anterior,
    e1.`year` año_viejo
from person p
inner join student s
	on p.DNI=s.DNI
inner join enrolled e
	on e.studentDNI=s.DNI
inner join enrolled e1
	on e1.`year`<e.`year` and e1.studentDNI=e.studentDNI
inner join `subject` su
	on su.subject_id=e.subject_id
where e.`year`=2021 and e1.grade>=5 and s.DNI in(
	select s.DNI
    from student s
    inner join enrolled e
		on e.studentDNI=s.DNI and e.grade>=5
	inner join enrolled e1
		on e1.`year`<e.`year`
	inner join `subject` su
		on su.subject_id=e.subject_id
	group by s.DNI
    having count(e.`year`)>1 and su.acronym="FOL"
	);