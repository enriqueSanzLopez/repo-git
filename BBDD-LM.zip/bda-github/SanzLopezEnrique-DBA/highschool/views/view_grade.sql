use highschool;

create view if not exists view_grade as
	select c.acronym course, su.acronym `subject`, p.surname surname, p.`name` `name`, e.grade grade
	from person p
	inner join student s
		on s.DNI=p.DNI
	inner join enrolled e
		on s.DNI=e.studentDNI
	inner join subject su
		on e.subject_id=su.subject_id
	inner join course c
		on c.course_id=s.course_id
	order by c.acronym asc, su.acronym asc, p.surname asc, p.`name` asc;