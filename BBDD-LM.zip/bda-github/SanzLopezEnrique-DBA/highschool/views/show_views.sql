use highschool;

show full tables
where table_type='VIEW';/*Para mostrar solo las tablas de una base de datos que son views*/