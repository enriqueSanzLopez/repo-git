use highschool;

create view if not exists view_schedule as
	select concat(y.start_year,"/",y.end_year) year, p.surname surname, p.name name, c.acronym course, s.acronym subject, s.name subject_name, s.hours hours
	from teacher t
	inner join person p
		on t.dni=p.dni
	inner join teaches te
		on t.DNI=te.teacherDNI
	inner join subject s
		on s.subject_id=te.subject_id
	inner join course c
		on c.course_id=s.course_id
	inner join `year` y
		on te.`year`=y.start_year
	order by year asc, p.surname asc, p.name asc, c.acronym asc, s.acronym asc;