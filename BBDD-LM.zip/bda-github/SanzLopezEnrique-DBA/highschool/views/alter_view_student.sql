use highschool;

alter view
view_student as
	select concat(c.acronym,"-",g.letter) `group`, p.DNI dni, s.NIA nia, p.`name` `name`, p.surname surname, p.birth_date birth_date, p.phone, p.corporate_email corporate_email, p.personal_email personal_email
	from person p
	inner join student s
		on s.DNI=p.DNI
	inner join `group` g
		on g.course_id=s.course_id and g.letter=s.group_letter
	inner join course c
		on c.course_id=g.course_id;