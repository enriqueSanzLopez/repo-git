use highschool;

create view if not exists view_group as
	select c.acronym acronym, g.letter letter, t.DNI tutorDNI, p.`name` tutor_name, p.surname tutor_surname, count(s.DNI) students
	from course c
	inner join `group` g
		on g.course_id=c.course_id
	inner join teacher t
		on t.DNI=g.tutorDNI
	inner join person p
		on p.DNI=t.DNI
	inner join student s
		on s.group_letter=g.letter and s.course_id=g.course_id
	group by t.DNI
    order by c.acronym asc, p.`name` asc;