use highschool;

create view if not exists view_teacher as
	select p.DNI dni, p.`name` `name`, p.surname surname, p.birth_date birth_date, p.phone phone, p.corporate_email corporate_email, p.personal_email personal_email
	from teacher t
	inner join person p
		on t.dni=p.dni;