use highschool;

create or replace view view_former_student as
	select concat(c.acronym,"-",g.letter) `group`,
		p.DNI dni,
        s.NIA nia,
        p.`name` `name`,
        p.surname surname,
        p.birth_date birth_date,
        p.phone,
        p.corporate_email corporate_email,
        p.personal_email personal_email
		from person p
		inner join student s
			on s.DNI=p.DNI
		inner join `group` g
			on g.course_id=s.course_id and g.letter=s.group_letter
		inner join course c
			on c.course_id=g.course_id
	where p.DNI not in(
		select p.DNI
		from person p
		inner join student s
			on s.DNI=p.DNI
		inner join enrolled e
			on e.studentDNI=s.DNI
		inner join `year` y
			on y.start_year=e.`year`
		where y.start_year=2021 and y.end_year=2022
	);