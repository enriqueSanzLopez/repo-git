use highschool;

create view if not exists view_daw as
	select c.acronym course, g.letter group_letter, p.DNI dni, s.NIA nia, p.`name` `name`, p.surname surname, p.birth_date birth_date, p.phone phone, p.corporate_email corporate_email, p.personal_email personal_email
	from course c
	inner join `group` g
		on g.course_id=c.course_id
	inner join student s
		on s.course_id=g.course_id and s.group_letter=g.letter
	inner join person p
		on p.DNI=s.DNI
	where c.acronym="DAW";