use highschool;

drop view view_group;