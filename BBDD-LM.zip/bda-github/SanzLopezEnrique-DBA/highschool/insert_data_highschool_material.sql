use highschool;

insert into material(material_id, name, amount) values
(1001, "Rotulador pizarra Pilot Azul", 20),
(1002, "Rotulador pizarra Pilot Rojo", 20),
(1003, "Rotulador pizarra Pilot Verde", 20),
(2001, "Boli Pilot Azul", 50),
(2002, "Boli Pilot Rojo", 50),
(2003, "Boli Pilot Verde", 50);
