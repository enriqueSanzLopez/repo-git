use highschool;

drop function if exists can_student_promote;

delimiter //
create function can_student_promote(
	in DNI varchar(10),
    in `year` int
	) returns boolean
begin
	/*Declarar créditos*/
	declare total int;
    declare conseguidos int;
    declare curso int;
    declare asignaturas int;
    /*Comprobar las matriculaciones del alumno*/
    select coalesce(count(e.subject_id),0) into asignaturas
    from enrolled e
    where e.studentDNI=DNI and e.`year`=`year`;
    if asignaturas=0 then
		return null;
    end if;
    /*Declarar el curso del alumno*/
    /*Obtener curso*/
    select c.course_id into curso
    from course c
    inner join student s
		on s.course_id=c.course_id
	where s.DNI=DNI;
    /*Averiguar los créditos que hay en el curso del alumno*/
    select sum(s.ects) into total
    from `subject` s
    inner join enrolled e
		on e.subject_id=s.subject_id
	inner join student st
		on st.DNI=e.studentDNI
	where e.studentDNI=DNI and s.course_id=curso and e.`year`=`year`;
    /*Averiguar los créditos superados por el alumno*/
    select sum(s.ects) into conseguidos
    from `subject` s
    inner join enrolled e
		on e.subject_id=s.subject_id
	inner join student st
		on st.DNI=e.studentDNI
	where e.studentDNI=DNI and e.`year`=`year` and s.course_id=curso and e.grade>=5;
    if (conseguidos/total)*100>=80 then
		return true;
	else
		return false;
	end if;
end; //
delimiter ;