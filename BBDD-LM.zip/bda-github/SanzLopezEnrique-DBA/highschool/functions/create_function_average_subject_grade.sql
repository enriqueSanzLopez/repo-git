use highschool;

drop function if exists average_subject_grade;

delimiter //
create function average_subject_grade(
	in subject_id varchar(4),
	in `year` int
	) returns decimal(4,2)
begin
	declare resultado decimal(4,2);
	select avg(grade) into resultado
    from enrolled e
    where e.subject_id=subject_id and e.`year`=`year`;
    return resultado;
end; //
delimiter ;