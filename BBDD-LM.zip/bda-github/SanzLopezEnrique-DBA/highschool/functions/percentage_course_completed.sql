use highschool;

drop function if exists percentage_course_completed;

delimiter //
create function percentage_course_completed(
	in studentDNI varchar(10)
    ) returns decimal(5,2)
begin
	declare total int;
    declare aprobados int;
    declare curso int;
    declare resultado decimal(5,2);
    /*Obtener curso*/
    select c.course_id into curso
    from course c
    inner join student s
		on s.course_id=c.course_id
	where s.DNI=studentDNI;
    /*Averiguar los créditos que hay en el curso del alumno*/
    select sum(s.ects) into total
    from `subject` s
    inner join enrolled e
		on e.subject_id=s.subject_id
	where s.course_id=curso;
    /*Averiguar los créditos superados por el alumno*/
    select coalesce(sum(s.ects),0) into aprobados
    from `subject` s
    inner join enrolled e
		on e.subject_id=s.subject_id
	inner join student st
		on st.DNI=e.studentDNI
	where e.studentDNI=studentDNI and s.course_id=curso and e.grade>=5;
    set resultado=(100*aprobados)/total;
    return resultado;
end; //
delimiter ;