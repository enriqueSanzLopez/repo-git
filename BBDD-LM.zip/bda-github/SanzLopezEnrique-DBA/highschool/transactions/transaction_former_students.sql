/*Pasos para importar el fichero

Primero descargamos el fichero former_students.csv
Como former_students.csv contiene datos tanto de person como
de student, por consola usamos el comando cut para dividir el
archivo en dos csv nuevos que se puedan importar a ambas tablas
mediante el siguiente formato:

cut -d "," -f "1-4" former_students.csv > nuevo_students.csv
cut -d, -f1,5-10 former_students.csv > nuevo_persons.csv

Con esto hemos creado dos nuevos ficheros llamados nuevo_students.csv
y nuevo_persons.csv que tienen los datos acomodados al formato de las
tablas de nuestra base de datos*/

/*Usamos la base de datos highschool*/
use highschool;

/*Comenzamos la transacción y desactivamos el autocommit*/
set autocommit=0;

start transaction;

/*Bloqueamos la tabla person hasta que terminemos la transacción*/
lock table person write;

/*Comenzamos el import de nuevo_persons.csv*/
load data local infile '/home/enrlop/Documents/bda-github/SanzLopezEnrique-DBA/highschool/transactions/nuevo_persons.csv'
into table person
fields terminated by ','
lines terminated by '\n'
ignore 1 lines
(DNI,name,surname,phone,birth_date,personal_email,corporate_email);

/*Como algunos de los nombres de alumnos estaban en minúsculas,
se tienen que cambiar los nombres a mayúsculas para que se detecten
como válidos y hacer un rollback al inicio después, para después
volver a ejecutar la transacción*/

rollback;

lock table person write;

load data local infile '/home/enrlop/Documents/bda-github/SanzLopezEnrique-DBA/highschool/transactions/nuevo_persons.csv'
into table person
fields terminated by ','
lines terminated by '\n'
ignore 1 lines
(DNI,name,surname,phone,birth_date,personal_email,corporate_email);


/*Comenzamos con el import de nuevo_students.csv*/
lock table student write;

/*Creamos un punto de guardado*/
savepoint persons_loaded;

/*Comenzamos el import de nuevo_students.csv*/
load data local infile '/home/enrlop/Documents/bda-github/SanzLopezEnrique-DBA/highschool/transactions/nuevo_students.csv'
into table student
fields terminated by ','
lines terminated by '\n'
ignore 1 lines
(DNI,NIA,course_id,group_letter);

/*Hacemos un rollback hasta persons_loaded para volver a ejecutar*/
rollback to persons_loaded;

/*Faltan grupos que no existen en la tabla original, por lo que hay que
bloquear la tabla grupo y enrolled e insertarlos*/
lock table `group` write;

INSERT INTO `group`(course_id, letter, tutorDNI) VALUES
(1, "B", "17286956H");

lock table student write;

/*Creamos un savepoint para el insert*/
savepoint introduce_group;

load data local infile '/home/enrlop/Documents/bda-github/SanzLopezEnrique-DBA/highschool/transactions/nuevo_students.csv'
into table student
fields terminated by ','
lines terminated by '\n'
ignore 1 lines
(DNI,NIA,course_id,group_letter);

/*Aunque ahora no hay errores, aquí se haría el
rollback to introduce_group;
en caso de necesidad*/

/*Ya no hay problemas y hemos importado exitosamente los datos
por tanto desbloqueamos las tablas*/
unlock tables;

/*Terminamos la transacción*/
commit;

/*Activamos el autocommit*/
set autocommit=1;

select *
from person;

select *
from student;