use highschool;

drop function if exists get_teaching_students;

delimiter //
create function get_teaching_students(
	in teacherDNI varchar(10),
    in `year` int
    ) returns int
begin
	declare cantidad int;
    select count(s.DNI) into cantidad
    from student s
    inner join enrolled e
		on e.studentDNI=s.DNI
	inner join teaches t
		on t.subject_id=e.subject_id and t.`year`=e.`year`
	where t.teacherDNI=teacherDNI and t.`year`=`year`;
	return cantidad;
end; //
delimiter ;