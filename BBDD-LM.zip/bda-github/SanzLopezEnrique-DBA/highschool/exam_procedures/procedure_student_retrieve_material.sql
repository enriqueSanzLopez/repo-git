use highschool;

drop procedure if exists student_retrieve_material;

delimiter //
create procedure student_retrieve_material(
	in studentDNI varchar(10),
    in material_id int,
    in amount int
    )
not deterministic
begin
    declare tutor varchar(10);
    declare letra char;
    declare curso int;
    /*Averiguar el grupo*/
    select s.group_letter into letra
    from student s
    where s.DNI=studentDNI;
    select s.course_id into curso
    from student s
    where s.DNI=studentDNI;
    /*Averiguar el tutor del grupo*/
    select g.tutorDNI into tutor
    from `group` g
    where g.letter=letra and g.course_id=curso;
    /*Llamar al proceso retrieve_material con el tutor del grupo*/
    call retrieve_material(tutor, material_id, amount);
end; //
delimiter ;