use highschool;

drop trigger if exists can_enroll_fct;

delimiter //
create trigger can_enroll_fct
	before insert on enrolled
    for each row
    begin
		declare FCT_acr varchar(5);
        declare nota decimal(4,2);
        declare mensaje text;
		select s.acronym into FCT_acr
        from `subject` s
        where s.subject_id=new.subject_id;
        /*Comprobar si se está matriculando en FCT*/
        if FCT_acr="FCT" then
			/*La mejor nota de FOL anterior al insertar del FCT*/
            select coalesce(max(e.grade),0) into nota
            from enrolled e
            inner join `subject` s
				on s.subject_id=e.subject_id
			where s.acronym="FOL" and e.`year`<new.`year` and e.studentDNI=new.studentDNI;
            if nota<5 then
				/*Nunca antes ha aprobado FOL*/
                set mensaje=concat("The student \"", new.studentDNI, "\" can't enroll in the FCT subject \"", new.subject_id, "\" because he hasn't passed the FOL subject.");
                signal sqlstate '45000'
				set message_text=mensaje;
            end if;
        end if;
    end; //
delimiter ;