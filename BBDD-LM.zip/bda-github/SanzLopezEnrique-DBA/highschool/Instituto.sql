drop database if exists instituto;
create database instituto;
use instituto;

create table familia(
	familia_id int primary key auto_increment,
    `name` varchar(50) not null unique key
    );
create table persona(
	DNI varchar(10) primary key,
    nombre varchar(50) not null,
    apellidos varchar (100) not null,
    fecha_nacimiento date not null,
    telefono varchar(20) not null,
    correo_electronico_personal varchar(100) not null,
    correo_electronico_corporativo varchar(100) null
    );

create table ciclo(
	ciclo_id int primary key auto_increment,
    nombre varchar(50) not null,
    siglas varchar(5) not null unique key,
    familia_id int not null,
    foreign key(familia_id)references familia(familia_id)
    );
/*He dejado la relacion entre ciclo y modulo como 1-n*/
create table modulo(
	modulo_id int primary key auto_increment,
    nombre varchar(50) not null,
    siglas varchar(3) not null unique key,
    ciclo_id int not null,
    foreign key(ciclo_id)references ciclo(ciclo_id)
    );

create table curso(
	curso_id int primary key auto_increment,
    año_inicio date not null,
    año_fin date not null
    );

create table grupo(
	grupo_id int primary key auto_increment,
    ciclo_id int not null,
    foreign key(ciclo_id)references ciclo(ciclo_id),
    letra char,
    unique key(ciclo_id, letra),
    DNI varchar(10)
    );

create table profesor(
	DNI varchar(10) primary key,
    ciclo_id int not null,
    grupo_id int not null,
    foreign key(grupo_id)references grupo(grupo_id),
    foreign key(DNI)references persona(DNI)
    );

Alter table grupo
Add foreign key (DNI)references profesor(DNI);

create table estudiante(
	DNI varchar(10) primary key,
    foreign key(DNI)references persona(DNI),
    grupo_id int not null,
    foreign key(grupo_id)references grupo(grupo_id)
    );

create table profesor_modulo_curso(
	DNI varchar(10) not null,
    curso_id int not null,
    modulo_id int not null,
    primary key(DNI, curso_id, modulo_id),
    foreign key(DNI)references profesor(DNI),
    foreign key(curso_id)references curso(curso_id),
    foreign key(modulo_id)references modulo(modulo_id)
    );

create table estudiante_modulo_curso(
	DNI varchar(10) not null,
    modulo_id int not null,
    curso_id int not null,
    primary key(DNI, modulo_id, curso_id),
    foreign key(DNI)references estudiante(DNI),
    foreign key(modulo_id)references modulo(modulo_id),
    foreign key(curso_id)references curso(curso_id),
    /*Introducir la nota como un numero con decimales que
    tenga hasta 4 digitos solo 2 de los cuales sean decimales,
    Con check estamos asegurandonos de que la nota no sea menor que
    0 ni mayor que 10*/
    nota decimal(4,2) check (nota>=0 and nota<=10)
    );