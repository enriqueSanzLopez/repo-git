use highschool;

set foreign_key_checks = 0;

drop table if exists material;
create table material (
    material_id int primary key auto_increment,
    name varchar(100) not null,
    amount int unsigned not null default 0
);

drop table if exists material_history;
create table material_history (
    material_id int not null,
    teacherDNI varchar(10) not null,
    amount int unsigned not null,
    timestamp timestamp default current_timestamp,
    foreign key (material_id) references material(material_id),
    foreign key (teacherDNI) references teacher(DNI)
);

set foreign_key_checks = 1;
