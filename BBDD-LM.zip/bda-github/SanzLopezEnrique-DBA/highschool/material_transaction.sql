use highschool;

/*Desactivar la ejecución automática hasta que se diga los contrario*/
set autocommit=0;

/*Comenzar la transacción*/
start transaction;
/*Comprobar si hay suficiente*/
select *
from material
where id=2001 for update;
/*Realizar los update e insert*/
/*Si hay suficiente, se procede al resto*/
savepoint cantidad;
/*Modificar la tabla de materiales*/
update material
set amount=amount-20
where id=2001;
/*Bloquear el material y la tabla hasta que se realicen los cambios*/
lock table material_history write;
/*Registrar al profesor que se lo ha llevado*/
insert into material_history (material, teacherDNI, amount) values
(2001, "93224949S", 20);

/*Desbloquear las tablas*/
unlock tables;

commit;

/*Reestablecer el autocommit*/
set autocommit=1;

select *
from material;