use cinema;

select distinct g.name
from genre g
inner join genre_film gf
	on gf.genre=g.id
inner join film f
	on gf.film=f.id
where not exists(
	select p.film
    from performs p
    inner join actor a
		on a.id=p.actor
	where p.film=f.id
    )
order by g.name asc;