use cinema;

select distinct a.id, a.name
from actor a
inner join performs p
	on p.actor=a.id
where p.role='Principal' and year(a.birth_date)<1950
order by a.name;