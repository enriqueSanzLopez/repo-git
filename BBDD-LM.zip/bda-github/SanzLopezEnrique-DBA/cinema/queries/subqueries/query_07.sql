use cinema;

select b.id, b.title, b.writer
from book b
where not exists(
	select f.book
	from film f
    where f.book=b.id
    );