use cinema;

select distinct b.id, b.title, b.writer
from book b
inner join film f
	on f.book=b.id
where f.year<2000 and f.year>=1990
order by b.title asc;