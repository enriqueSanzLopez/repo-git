use cinema;

select distinct c.id, c.name
from country c
inner join actor a
	on a.country=c.id
inner join performs p
	on p.actor=a.id
inner join film f
	on p.film=f.id
inner join genre_film gf
	on gf.film=f.id
inner join genre g
	on gf.genre=g.id
where g.name="Comedia"
order by c.name asc;