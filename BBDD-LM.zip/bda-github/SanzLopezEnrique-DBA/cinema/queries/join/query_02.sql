use cinema;

select f.id, f.title
from film f
inner join genre_film gf
	on gf.film=f.id
inner join genre g
	on gf.genre=g.id
where g.name="Comedia"
order by f.title;