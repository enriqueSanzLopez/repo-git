use cinema;

select f.id, f.title
from film f
inner join performs p
	on p.film=f.id
inner join actor a
	on p.actor=a.id
where f.director=a.name
order by f.title asc;