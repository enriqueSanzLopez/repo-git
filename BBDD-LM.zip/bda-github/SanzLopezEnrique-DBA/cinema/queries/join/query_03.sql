use cinema;

select f.id, f.title
from film f
inner join book b
	on f.book=b.id
where b.year<1950
order by f.title asc;