use cinema;

select distinct c.id country
from country c
inner join actor a
	on a.country=c.id
order by c.id asc;