use cinema;

select count(distinct gf.film) how_many_films
from genre_film gf
where gf.genre='BB5' or gf.genre='GG4' or gf.genre='JH6';