use cinema;

select avg(length) average
from film
where year=1987;