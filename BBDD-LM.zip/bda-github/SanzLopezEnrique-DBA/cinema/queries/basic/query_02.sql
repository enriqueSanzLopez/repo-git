use cinema;

select id, title
from film
where year<1970 and book is null
order by title asc;