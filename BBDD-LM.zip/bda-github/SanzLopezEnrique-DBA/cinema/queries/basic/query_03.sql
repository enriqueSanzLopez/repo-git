use cinema;

select id, name
from actor
where name like "%John%";