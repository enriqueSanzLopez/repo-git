use cinema;

select id, title
from film
where length>120 and year>=1980 and year<1990;