use cinema;

select min(year) year
from book;