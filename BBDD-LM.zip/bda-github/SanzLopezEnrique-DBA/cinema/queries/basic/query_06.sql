use cinema;

select count(id) how_many_films
from film
where length>120 and year>=1980 and year<1990;