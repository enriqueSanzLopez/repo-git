use cinema;

select sum(length) total_length
from film
where director='Steven Spielberg';