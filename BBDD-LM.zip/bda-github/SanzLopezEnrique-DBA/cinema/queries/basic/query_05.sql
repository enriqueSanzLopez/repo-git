use cinema;

select f.id, f.title
from film f
inner join book b
	on f.book=b.id
where f.director like "%Pakula%";