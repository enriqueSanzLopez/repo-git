use cinema;

/*The title of the film must be of 80 characters at most*/
alter table film
modify column title varchar(80) not null;

/*The length of the film must be an integer without sign*/
alter table film
modify column length int unsigned;

/*Lock foreign keys*/
set foreign_key_checks=0;

/*The film of the film_review table must be the primary key*/
alter table film_review
modify column film varchar(5),
add column email varchar(100),
add primary key(film, email);

/*Unlock foreign keys*/
set foreign_key_checks=1;