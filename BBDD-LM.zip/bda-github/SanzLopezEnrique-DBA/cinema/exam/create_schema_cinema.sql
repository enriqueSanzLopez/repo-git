drop database if exists cinema;
create database cinema;
use cinema;

create table country(
	/*Id of the country*/
	id varchar(5) primary key,
    /*Name of the country*/
    `name` varchar(25) not null
    );

create table book(
	/*Id of the book*/
	id varchar(5) primary key,
    /*Title of the book*/
    title varchar(70) not null,
    /*Year of the book*/
    `year` int,
    /*Writer of the book*/
    writer varchar(80) not null
    );

create table genre(
	/*Genre id*/
	id varchar(5) primary key,
    /*Name of the genre*/
    `name` varchar(80) not null
    );
    
create table actor(
	/*Id of the actor*/
	id varchar(5) primary key,
    /*Name of the actor*/
    `name` varchar(25) not null,
    /*Actor's date of birth*/
    birth_date date not null,
    /*Country of the actor*/
    country varchar(5) not null,
    foreign key(country)references country(id)
    );
    
create table film(
	/*Code of the film*/
	id varchar(5) primary key,
    /*title of the film*/
    title varchar(70),
    /*Year of the film*/
    `year` int,
    /*Length of the film*/
    length int,
    /*Director of the film*/
    director varchar(80) not null,
    /*Book which the film is based*/
    book varchar(5),
    foreign key(book)references book(id)
    );
    
create table film_review(
	/*Film that is reviewed*/
	film varchar(5),
    foreign key(film)references film(id) on delete cascade,
    /*Single digit number with a single decimal, without sign*/
    rating float(1, 1) unsigned not null check(rating>0 and rating<=5)
    );

create table performs(
	/*Actor that performs in the film*/
	actor varchar(5),
    foreign key(actor)references actor(id),
    /*Film in which the actor performs*/
    film varchar(5),
    foreign key(film)references film(id),
    primary key(actor, film),
    /*Role of the actor in the film*/
    `role` varchar(10) not null
    );

create table genre_film(
	/*Film that is assigned to a genre*/
	film varchar(5),
    foreign key(film)references film(id) on delete cascade,
    /*Genre that is assigned to the film*/
    genre varchar(5),
    foreign key(genre)references genre(id) on delete cascade,
    primary key(film, genre)
    );

/*To see the tables and see if they are correct*/
/*show tables;*/