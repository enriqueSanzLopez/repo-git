use cinema;

/*Deleting genre_film and genre*/
drop table if exists genre_film, genre;

/*To see the tables and see if they are correct*/
/*show tables;*/