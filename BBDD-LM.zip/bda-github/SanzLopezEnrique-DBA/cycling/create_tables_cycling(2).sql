drop database if exists cycling;
create database cycling;
use cycling;

create table team(
	`name` varchar(25) primary key,
    trainer varchar(50)
    );

create table cyclist(
	`number` int primary key,
    `name` varchar(25),
    age int,
    team varchar(25),
    foreign key(team)references team(`name`)
	);

create table jersey(
	id varchar(3) primary key,
    `type` varchar(30),
    prize int,
    color varchar(30)
	);
    
create table stage(
	id int primary key,
    km int,
    departure varchar(50),
    arrival varchar(50),
    win_cyclist int,
    foreign key(win_cyclist)references cyclist(`number`)
    );
    
create table climb(
	`name` varchar(30) primary key,
    height int,
    category char,
    slope decimal,
    stage int,
    foreign key(stage)references stage(id),
    win_cyclist int,
    foreign key(win_cyclist)references cyclist(`number`)
    );

create table wears(
	cyclist int,
    jersey varchar(3),
    stage int,
    primary key(stage, jersey),
    foreign key(cyclist)references cyclist(`number`),
    foreign key(jersey)references jersey(id),
    foreign key(stage)references stage(id)
    );