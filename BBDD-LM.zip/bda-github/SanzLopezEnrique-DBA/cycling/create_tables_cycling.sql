drop database if exists cycling;
create database cycling;
use cycling;

create table team(
	`name` varchar(25) primary key,
    trainer varchar(50)
    );

create table cyclist(
	`number` int primary key check(`number`>0),
    `name` varchar(25) not null,
    age int,
    team varchar(25) not null,
    foreign key(team)references team(`name`)
    );

create table stage(
	id int primary key,
    km int,
    `start` varchar(25),
    `end` varchar(25),
    cyclist int,
    foreign key(cyclist)references cyclist(`number`)
    );

create table jersey(
	id char(3) primary key,
    `type` varchar(30),
    prize int,
    color varchar(30)
    );

create table pass(
	`name` varchar(30) primary key,
    height int,
    category char,
    slope decimal,
    stage int not null,
    foreign key(stage)references stage(id),
    cyclist int,
    foreign key(cyclist)references cyclist(`number`)
    );

create table wears(
	stage int,
    jersey char(3),
    primary key(stage, jersey),
    cyclist int not null,
    foreign key(stage)references stage(id),
    foreign key(jersey)references jersey(id),
    foreign key(cyclist)references cyclist(`number`)
    );