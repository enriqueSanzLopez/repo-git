use cycling;

select s.id, count(c.name) climbs
from stage s
inner join climb c
	on c.stage=s.id
group by s.id
order by s.id asc;