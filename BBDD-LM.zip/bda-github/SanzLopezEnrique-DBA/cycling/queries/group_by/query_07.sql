use cycling;

select t.trainer
from team t
inner join cyclist c
	on c.team=t.name
inner join wears w
	on w.cyclist=c.number
group by t.trainer
having count(w.jersey)>=all(
	select count(w.jersey)
    from wears w
    inner join cyclist c
		on c.number=w.cyclist
	inner join team t
		on t.name=c.team
	group by t.name
    );