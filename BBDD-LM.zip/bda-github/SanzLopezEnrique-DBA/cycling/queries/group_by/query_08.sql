use cycling;

select c.name
from cyclist c
inner join climb cl
	on cl.win_cyclist=c.number
group by c.name
having count(cl.name)>1;