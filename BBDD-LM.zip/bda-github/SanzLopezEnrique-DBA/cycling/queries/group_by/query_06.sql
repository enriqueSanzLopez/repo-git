use cycling;

select t.name, avg(c.age) average_age
from team t
inner join cyclist c
	on c.team=t.name
group by t.name
having average_age>=ALL(
	select avg(c.age)
    from cyclist c
    inner join team t
		on t.name=c.team
	group by t.name
    );