use cycling;

select c.name, c.category
from climb c
inner join cyclist cy
	on cy.number=c.win_cyclist
where cy.team='Banesto';