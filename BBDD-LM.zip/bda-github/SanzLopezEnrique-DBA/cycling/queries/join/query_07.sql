use cycling;

select distinct c.name, s.id stage
from cyclist c
inner join stage s
	on s.win_cyclist=c.number
inner join wears w
	on c.number=w.cyclist and s.id=w.stage
inner join jersey j
	on j.id=w.jersey
where j.color='Amarillo';