use cycling;

select distinct t.name, t.trainer
from team t
inner join cyclist c
	on c.team=t.name
where c.age>33;