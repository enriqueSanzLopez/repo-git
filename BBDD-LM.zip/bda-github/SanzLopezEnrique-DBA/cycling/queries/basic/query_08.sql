use cycling;

select avg(age)
from cyclist;