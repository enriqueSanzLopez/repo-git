use cycling;

select id
from stage
where departure=arrival;