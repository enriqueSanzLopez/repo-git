use cycling;

select count(*)
from team;