use cycling;

select min(height), max(height)
from climb;