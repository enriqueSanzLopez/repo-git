use cycling;

select count(*)
from cyclist;