use cycling;

select id, type, color, prize
from jersey;