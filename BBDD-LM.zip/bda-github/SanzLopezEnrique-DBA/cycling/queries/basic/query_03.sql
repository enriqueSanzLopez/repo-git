use cycling;

select name, height
from climb
where category='E';