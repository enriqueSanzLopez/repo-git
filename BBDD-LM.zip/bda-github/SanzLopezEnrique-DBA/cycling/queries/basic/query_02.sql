use cycling;

select number, name
from cyclist
where age<=25;