use cycling;

select name
from cyclist
where age=(select min(age) from cyclist);