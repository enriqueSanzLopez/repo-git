use cycling;

select c.name
from cyclist c
where c.age=(
	select min(c.age)
	from cyclist c
    inner join stage s
		on s.win_cyclist=c.number
        )
	and c.number in(
    select s.win_cyclist
    from stage s
    );