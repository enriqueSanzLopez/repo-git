use cycling;

select distinct c.number, c.name
from cyclist c
inner join climb cl
	on cl.win_cyclist=c.number
where cl.height=(select max(cl.height) from climb cl);