use cycling;

select s.departure, s.arrival
from stage s
inner join climb c
	on c.stage=s.id
where c.slope=(select max(c.slope) from climb c);