use cycling;

select distinct s.id, s.departure
from stage s
where s.id not in(select distinct c.stage from climb c);