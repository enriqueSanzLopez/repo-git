use cycling;

select distinct name
from climb
where height>(select avg(height) from climb);