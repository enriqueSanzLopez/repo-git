use music;

select fc.name, fc.address, b.name
from fan_club fc
inner join band b
	on fc.band=b.id
where b.country='Spain';