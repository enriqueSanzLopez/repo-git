use music;

/*Mostrar los diferentes roles en una banda*/
select DISTINCT `role`
from `band_component`;