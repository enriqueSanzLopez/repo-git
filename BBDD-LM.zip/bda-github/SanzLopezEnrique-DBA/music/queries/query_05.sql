use music;

/*Conseguir los clubs ordenados por su tamaño*/
select `name`, `num`
from `fan_club`
order by `num` asc;