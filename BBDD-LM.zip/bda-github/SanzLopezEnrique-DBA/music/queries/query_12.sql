use music;

select s.title
from song s
inner join song_album sa
	on sa.song=s.id
inner join album a
	on a.id=sa.album
inner join band b
	on b.id=a.band
where b.country='Spain' AND s.lenght=4;