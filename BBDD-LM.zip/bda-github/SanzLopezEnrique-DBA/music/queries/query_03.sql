use music;

/*Nombres de las canciones de mas de 5 minutos*/
select `title`
from song
where `length`>5;