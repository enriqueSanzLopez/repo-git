use music;

select s.title
from song s
right join song_album sa
	on s.id=sa.song
right join album a
	on sa.album=a.id
where a.name=s.title;