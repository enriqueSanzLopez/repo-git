use music;

select distinct a.name
from album a
inner join song_album sa
	on a.id=sa.album
inner join song s
	on sa.song=s.id
where s.lenght>5;