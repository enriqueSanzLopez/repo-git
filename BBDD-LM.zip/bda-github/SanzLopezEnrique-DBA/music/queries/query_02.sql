use music;

/*Mostrar los nombres de las bandas no Españolas*/
select `name`
from `band`
where `country`!='Spain';