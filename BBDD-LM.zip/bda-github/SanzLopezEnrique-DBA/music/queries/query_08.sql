use music;

select a.name
from artist a
right join band_component bc
	on a.dni=bc.dni
right join band b
	on bc.band=b.id
where b.country='Spain';