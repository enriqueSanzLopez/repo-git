use music;

/*Contar el numero de albumes*/
select count(id)
from album;