use music;

/*Mostrar los nombres y las direcciones de los clubs con mas de 500 personas*/
select `name`, `address`
from `fan_club`
where `num`>500;