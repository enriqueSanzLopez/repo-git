use music;

select c.name, c.address
from company c
inner join album a
	on c.id=a.company
where a.name like 'A%';