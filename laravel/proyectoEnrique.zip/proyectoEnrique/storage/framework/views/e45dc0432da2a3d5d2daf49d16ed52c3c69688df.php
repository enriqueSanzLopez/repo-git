<?php $__env->startSection('titulo', 'Inicio'); ?>
<?php $__env->startSection('contenido'); ?>
    <main class="bg-light text-dark">
        <div class="card" style="width: 18rem;">
            <img src="img/T.png" class="card-img-top" alt="Icono NoTebeo">
            <div class="card-body">
                <h5 class="card-title">Bienvenido a NoTebeo</h5>
                <p class="card-text text-justify">La página para forofos de los tebeos y los comics, consulta nuestros eventos.</p>
                <a href="<?php echo e(route('events.index')); ?>" class="btn btn-primary">Consultar</a>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\Repositorio Git\laravel\proyectoEnrique\resources\views/index.blade.php ENDPATH**/ ?>