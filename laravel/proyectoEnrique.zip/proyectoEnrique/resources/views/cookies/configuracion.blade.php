@extends('layout')
@section('titulo', 'Configuración de cookies')
@section('contenido')
<main class="bg-light text-dark">
    <p>
        Lorem fistrum se calle ustée pecador de la pradera apetecan ese que llega ese pedazo de hasta luego Lucas. Diodeno pupita caballo blanco caballo negroorl va usté muy cargadoo condemor hasta luego Lucas qué dise usteer ahorarr por la gloria de mi madre amatomaa sexuarl. A gramenawer diodenoo benemeritaar quietooor se calle ustée caballo blanco caballo negroorl te va a hasé pupitaa. Se calle ustée ese pedazo de a wan va usté muy cargadoo apetecan ese hombree. Ese que llega quietooor a gramenawer fistro ese que llega hasta luego Lucas por la gloria de mi madre a gramenawer. No puedor ese hombree quietooor a gramenawer torpedo apetecan pecador ahorarr pecador te va a hasé pupitaa. Me cago en tus muelas ese hombree está la cosa muy malar al ataquerl hasta luego Lucas benemeritaar.

Ahorarr pupita qué dise usteer ahorarr quietooor. Se calle ustée está la cosa muy malar no te digo trigo por no llamarte Rodrigor quietooor quietooor al ataquerl no te digo trigo por no llamarte Rodrigor amatomaa. Caballo blanco caballo negroorl por la gloria de mi madre hasta luego Lucas te voy a borrar el cerito diodeno a peich papaar papaar a wan de la pradera. Ese pedazo de sexuarl a gramenawer de la pradera te voy a borrar el cerito. Fistro no puedor ese pedazo de diodeno caballo blanco caballo negroorl. La caidita ese pedazo de no puedor papaar papaar al ataquerl te voy a borrar el cerito está la cosa muy malar. Ese hombree qué dise usteer fistro de la pradera está la cosa muy malar la caidita. De la pradera pecador mamaar papaar papaar va usté muy cargadoo va usté muy cargadoo ese que llega. Fistro qué dise usteer ahorarr por la gloria de mi madre mamaar a peich al ataquerl al ataquerl apetecan.

Condemor caballo blanco caballo negroorl diodenoo torpedo no te digo trigo por no llamarte Rodrigor te voy a borrar el cerito qué dise usteer me cago en tus muelas pecador condemor me cago en tus muelas. Pecador amatomaa la caidita a wan ese que llega diodenoo quietooor ese hombree condemor a gramenawer. Caballo blanco caballo negroorl ese que llega amatomaa ese pedazo de te voy a borrar el cerito pecador se calle ustée ese pedazo de te va a hasé pupitaa. Tiene musho peligro jarl la caidita me cago en tus muelas no puedor sexuarl. La caidita al ataquerl diodeno papaar papaar diodeno te voy a borrar el cerito mamaar. De la pradera quietooor pecador jarl. Apetecan ese pedazo de a gramenawer a peich quietooor.
    </p>
</main>
@endsection
