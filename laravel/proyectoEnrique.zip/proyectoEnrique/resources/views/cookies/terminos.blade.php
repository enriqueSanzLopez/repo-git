@extends('layout')
@section('titulo', 'Términos y condiciones de uso')
@section('contenido')
<main class="bg-light text-dark">
    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Unde ipsa perferendis dolore impedit officia asperiores quo necessitatibus soluta? Delectus suscipit eaque aspernatur facere et quo iste, modi quas quia eveniet.<br>
        <br>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Obcaecati officia itaque iste voluptatum enim? Harum numquam soluta nemo aut nobis accusantium eligendi, suscipit minus facilis magnam. Repellendus eaque dolorum eligendi!<br>
        <br>
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Voluptates, eius sunt eum ipsa aliquid, libero ratione itaque nihil quis ea aspernatur necessitatibus neque. Delectus possimus facere labore quam provident sint?
    </p>
</main>
@endsection
