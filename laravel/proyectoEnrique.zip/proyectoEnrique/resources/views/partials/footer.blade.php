<footer class="bg-dark text-white">
    <h3>Desarrollo Enrique</h3>
    <ul class="nav flex-column">
        <li class="nav-item">
          <a class="nav-link" href="{{route('politica')}}">Política de cookies</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="{{route('configuracion')}}">Configuración de cookies</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="{{route('privacidad')}}">Política de privacidad</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="{{route('terminos')}}">Términos y condiciones de uso</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Contacto</a>
        </li>
      </ul>
</footer>
