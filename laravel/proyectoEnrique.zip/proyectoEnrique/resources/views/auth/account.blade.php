@extends('layout')
@section('titulo', 'Cuenta')
@section('contenido')
    <main class="bg-light text-dark">
        <h1>Propiedades de la cuenta</h1>
    </main>
@endsection
